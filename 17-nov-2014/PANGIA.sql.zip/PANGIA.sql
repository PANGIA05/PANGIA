-- phpMyAdmin SQL Dump
-- version 2.11.11.3
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 17, 2014 at 08:58 PM
-- Server version: 5.5.36
-- PHP Version: 5.4.28

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `PANGIA`
--

-- --------------------------------------------------------

--
-- Table structure for table `abouts`
--

CREATE TABLE IF NOT EXISTS `abouts` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `image` varchar(150) NOT NULL,
  `description` longtext NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `abouts`
--

INSERT INTO `abouts` (`id`, `name`, `image`, `description`, `created_at`) VALUES
(1, 'About Us', 'about01.jpg', '<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry''s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of</p>\n\n<p>Lorem Ipsum. Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum" (The Extremes of Good and Evil) by</p>\n', '2014-11-17 18:15:39'),
(2, 'Neque porro', 'about01.jpg', '<h2>Quisquam</h2>\n\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry''s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not</p>\n\n<h2>Voluptatem</h2>\n\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry''s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not</p>\n\n<h2>Consequuntur</h2>\n\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry''s standard dummy text ever since the 1500s, when an unknown printer took a galley of type</p>\n', '2014-11-17 17:32:06');

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE IF NOT EXISTS `admins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `address` varchar(255) NOT NULL,
  `zip` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `username`, `password`, `firstname`, `lastname`, `email`, `phone`, `address`, `zip`) VALUES
(1, 'admin', '5f0e6cbd2cd61c2454101279a4d91ada', 'ashwani', 'kaushal', 'pardeep_grover@softprodigy.com', '9876543212', 'Chandigarh', '12345');

-- --------------------------------------------------------

--
-- Table structure for table `articlecategories`
--

CREATE TABLE IF NOT EXISTS `articlecategories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `articlecategories`
--


-- --------------------------------------------------------

--
-- Table structure for table `articles`
--

CREATE TABLE IF NOT EXISTS `articles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `author` varchar(255) NOT NULL,
  `user_id` int(11) NOT NULL,
  `amount` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `category` varchar(255) NOT NULL,
  `summary` text NOT NULL,
  `description` text NOT NULL,
  `image` varchar(255) NOT NULL,
  `totaldonation` int(255) NOT NULL,
  `press` varchar(255) DEFAULT NULL,
  `publicprivate` tinyint(4) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=157 ;

--
-- Dumping data for table `articles`
--

INSERT INTO `articles` (`id`, `author`, `user_id`, `amount`, `title`, `category`, `summary`, `description`, `image`, `totaldonation`, `press`, `publicprivate`, `status`, `date`) VALUES
(1, 'admin', 0, '3000', 'today article', '37', 'today article', 'today article', 'Article1409722272_article-image.png', 0, NULL, 0, 1, '2014-09-02 21:21:51'),
(30, 'user', 1246, '100000', 'Testing the site', '37', 'We would like to raise money for our concert.', 'Raising money for concert.', 'Article1403625613_alesis.jpeg', 0, NULL, 0, 1, '2014-09-24 21:30:13'),
(49, 'user', 1234, '4000', 'Fundraiser for the War Veterans', '17', 'Pleasee raise as much as you can for the family of the War veterans in World War II', 'Please raise as much as you can for the family of the War veterans in World War II. The raised money will go to the family of war veterans who belong to the Easy Company who fought in World War II. Easy Company was led by Major Winters.', 'Article1404458048_cscxzc.jpg', 8958, NULL, 0, 1, '2014-09-04 12:44:08'),
(94, 'user', 1234, '2000', 'Big Jax Fights the Big C', '28', '<p>Big Jax is a young, vibrant dog who needs a leg amputation due to a tumor in his left knee. Please help him in his fight against cancer!</p>', '<p>Meet Big Jax. He''s handsome, he''s smart, he''s playful... and he''s fighting cancer. After a round of chemo and steroids, he''s still not out of trouble. The veterinarians at University of Illinois have determined that Big Jax needs to have his left hind leg amputated. His cancer has started to grow into the bone of his left knee, and the leg has to go! Big Jax is one lucky dog. His owner has stood by him through thick and thin. He has already had many expensive chemo treatments and advanced diagnostics to check the progress of his cancer . With any luck, this surgery will be their last battle in their fight against this cancer. But after such a long journey, Jax needs our help! The estimate for Jax''s upcoming surgery to remove his leg is approximately $2,000. He will need not only surgery but post-op pain medications, follow up exams, and a special harness to help him get back on his feet again. After spending so much on his biopsy and chemo treatments, Big Jax and his mom need some help! The great news is that dogs make remarkable recoveries after having a leg amputated, and many eventually go on with life as usual very quickly! Big Jax should be able to go on with living a great life full of walks, doggy daycare, and lots of fun once he is recovered . We know you are out there, fellow dog lovers, so please help give a great young dog a chance at a full, happy life!</p>', 'Article1405678346_dog_image_0.jpg', 167, NULL, 0, 1, '2014-08-18 15:42:26'),
(96, 'user', 1247, '3000', 'Lila Javan''s Recovery Fund', '29', 'Lila Javan''s family and friends are uniting to raise money to help Lila conquer a second round of cancer. Please show your support!', 'Our lovely daughter/sister/aunt/friend Lila has been diagnosed with Acute Myeloid Leukemia for the second time. Four years ago, and ten years out of grad school at the American Film Institute, Lila was about to shoot the biggest movie of her career. She had worked hard for a decade to make it happen, in an industry where only 3% of the field are women. As we prepared to scout locations, Lila saw her doctor for what she thought was a cold that wouldn''t go away. She left the doctor''s office with Stage IV Leukemia. Lila beat the odds and AML with the help of her sister Maia, who was Lila''s donor for a Bone Marrow Transplant. Lila''s recovery was so miraculous that six months into remission, she ran the LA Marathon. As each year of remission passed, we took a collective sigh of relief. 90% of patients who fall out of remission do so in the first 2 years, and Lila was coming up on year 4, so we were hoping we''d seen the last of the nasty C word. In those four years Lila became an aunt, times two; she traveled to Egypt to shoot the uprising, and to India to explore with her friend Anjuli; she helped both parents move out from Boston to the west coast; she shared her passion for filmmaking as a mentor/professor to new cinematographers at RED in Hollywood; she went back to work and shot a beautiful movie for her friend Wade and was about to begin prepping a film she has spent the last two years developing with a best friend when a routine blood test, two weeks ago, insisted Lila make other plans. Lila has just finished her first round of chemo in preparation for Bone Marrow Transplant #2. Lila is without a doubt the strongest person we''ve ever met, and lovely and kind and smart and funny and talented and all of the things anyone could ever hope to be. And while we''re sure Maia and the brilliant doctors at UCLA will lead her to health once again, the process of treating AML is expensive, difficult and time consuming. Lila has health insurance, but this fund will help with all of her bills as she won''t be working for the rest of the year - rent, food, clothing, supplements, therapy and all of the other things we might take for granted when we are healthy and working. We can also help Lila reach her goal to climb Mt. Kilimanjaro in the next year. She has been saving for months and had planned to go in September. Let''s help her live that dream. NEVER PUT ANYTHING PAST LILA! AML is aggressive but survivable with another Bone Marrow Transplant, which for Lila will happen at the end of this month. Let''s help Lila climb this mountain so that she can get to Tanzania healthy! And then lets raise even more to HELP FIGHT CANCER! If we raise more than we need, we will happily donate it to others battling AML. And please visit www.bethematch.org to find out how you can be a bone marrow donor. The test is a simple swab of the mouth, and the donation is as easy as giving plasma. You could save a life! All by yourself! In just a few hours! Go get ''em, Lila. If anyone can beat this, you can! Love, your friends and family', 'Article1405683233_BePositive.gif', 3010, 'http://softprodigy.in/GoFundMe', 0, 1, '2014-08-18 17:03:53'),
(107, 'user', 1233, '400', 'test', '1', '<p>wdfesf</p>', '<p>dsfdsfds</p>', 'Article1405950965_baby-boy-wearing-hat.jpg', 500, NULL, 1, 0, '2014-08-21 19:26:05'),
(109, 'user', 1247, '10000', 'Barbara''s Road to Recovery', '12', '<p>Thank you for supporting Barbara''s road to recovery from bacterial pneumonia and septic shock.</p>', '<p>On the weekend of April 25-27, Barbara enjoyed a trip to Richmond, VA, accompanied by her daughter Christie''s family and her sister, Laura, to visit her youngest son, Michael and his girlfriend Amanda. They had a great time with grandson Pierce, 2, and granddaughter Lee Ellen, 7 months, touring Richmond, hiking, and visiting Jamestown. The Wednesday night after Barbara returned she spent the night with her oldest daughter, Julie, and played with her twin two year-old grandsons, Will and Cal. She finished up the week at work but by Friday, was tired and not feeling well. On Friday night she spoke with her son Jeff about how she felt like she was coming down with a cold. On Saturday, she reported to Julie that she had a fever of 101.5 the night before but that it was down to 99.8. Throughout the rest of Saturday, her kids lost touch with her. She felt worse and worse and by that night, her temp was 104.5 and she told herself she''d go to the emergency room in the morning. She wasn''t thinking clearly. On Sunday morning, she called Julie from the emergency room and said she had pneumonia and they were transferring her to Baylor Grapevine''s ICU. By that afternoon, she was on a ventilator, dialysis and in septic shock from the pneumonia. Her family and friends are in disbelief. Barbara is a healthy 64 year-old woman, a runner, with no underlying health issues, and someone who just worked a full week and played with grandkids. Her pneumonia was found to have been caused by group A streptococcal infection. Julie and her twins also tested positive and were quickly administered antibiotics and everyone who had been exposed was tested. This is a nasty bug that can take someone down, and fast. Her whole left lung and part of her right lung were filled with pneumonia. Septic shock is when your body shuts down in response to an infection. Barbara''s blood pressure plummeted to dangerous levels, which is characteristic of shock. Her kidneys shut down. Her heart was damaged by the infection. Her liver was damaged--basically all organ systems. Unfortunately, due to the lack of blood flow, Barbara may lose parts of her fingers and possibly toes. If she had not gone to the emergency room on Sunday, she undoubtedly would have passed away. The focus now is on healing her pneumonia and infection, weaning her off of continual dialysis, and eventually getting her off the ventilator. She has been sedated (not conscious) since Sunday afternoon. Barbara is an extremely sweet, strong, godly woman who has weathered many trials, including losing her husband, and we know her strength and faith, along with your prayers, have helped her survive and will continue to get her through this life-changing event. We so appreciate your prayers for her recovery as well as any financial support you can contribute towards her mounting hospital bills, future rehabilitation and therapy bills, follow-up visits and missed work. Any gift, no matter how small, will help out. We will update this page as Barbara''s condition and treatment progress. With much love,</p><p>Barbara''s family</p>', 'Article1406098789_images.jpg', 0, NULL, 1, 1, '2014-08-23 12:29:49'),
(111, 'user', 1246, '2000', 'Testing the site', '2', '<p>Testing the fundraiser</p>', '<p>Testing the fundraiser</p>', 'Article1406124234_hands-dance.jpg', 0, NULL, 1, 1, '2014-08-23 19:33:54'),
(112, 'user', 1216, '300', 'first compaing', '12', '<p>this is first test companing</p>', '<p>this is first test companing</p>', 'Article1406197086_baby-boy-wearing-hat.jpg', 8200, NULL, 0, 1, '2014-08-24 15:48:07'),
(113, 'user', 1216, '300', 'Sofptrodigy campaign', '37', '<p>Sofptrodigy campaignSofptrodigy campaigns</p>\r\n', '<p>Sofptrodigy campaignSofptrodigy campaign</p>\r\n', 'Article1406718560_photo 5.JPG', 0, NULL, 0, 1, '2014-08-30 16:39:20'),
(114, 'user', 1233, '8000', 'paragraph', '1', '<p>dfddd</p>', '<p>Tony is waging a war against a very aggressive brain cancer. This is  devastating news and we need to show them our love and support!</p>\r\n<p>Tony is waging a war against a very aggressive brain cancer. This is  devastating news and we need to show them our love and support!</p>\r\n<p>Tony is waging a war against a very aggressive brain cancer. This is  devastating news and we need to show them our love and support!</p>\r\n<p>Tony is waging a war against a very aggressive brain cancer. This is  devastating news and we need to show them our love and support!</p>\r\n<p>Tony is waging a war against a very aggressive brain cancer. This is  devastating news and we need to show them our love and support!</p>', 'Article1406723523_baby-boy-wearing-hat.jpg', 0, NULL, 0, 0, '2014-08-30 18:02:03'),
(121, 'user', 1233, '700', 'paragraph', '1', '<p>eee</p>', '<p>description</p>', 'Article1406809716_baby-boy-wearing-hat.jpg', 0, NULL, 0, 1, '2014-08-31 17:58:36'),
(122, 'user', 1234, '4000', 'testing', '27', '<p>testingtestingtestingtestingtestingtestingtestingtesting&nbsp;</p>', '<p>testingtesting&nbsp; testingtesting</p>', 'Article1406821587_as.jpg', 0, NULL, 0, 1, '2014-08-31 21:16:27'),
(123, 'user', 1233, '8000', 'new category test', '36', '<p>new category test</p>', '<p>new category test</p>', 'Article1406901899_images.jpg', 800, NULL, 0, 0, '2014-08-01 19:34:59'),
(124, 'admin', 1, '4000', 'Michael Chase TEST', '37', 'Here is a test of Article', 'Here is a test of Article', 'Article1407930587_practice-slow.jpg', 0, NULL, 0, 1, '2014-08-13 17:19:47'),
(125, 'admin', 1, '1235', 'payment', '37', 'https://basecamp.com/1973733/projects/6149943/messages/26913626', 'https://basecamp.com/1973733/projects/6149943/messages/26913626', 'Article1408544499_banner.jpg', 4200, 'Related Press FIRST COAST NEWS (VIDEO) - Woman tries to save pig from high school pork raffle NBC NEWS - JEFFERSON, GA (VIDEO) - Animal lover fights to "Save th ', 0, 1, '2014-08-20 19:51:41'),
(126, 'admin', 1, '3000', 'Test Firest', '37', 'This is for test', 'This is for test', 'Article1409201622_banner.jpg', 0, NULL, 0, 1, '2014-08-28 10:23:43'),
(127, 'user', 1234, '20000', 'Raise Money for music legends', '36', '<p><b>Legends</b> (aka <b>VH1''s Legends</b>) is a <a title="Music" href="http://en.wikipedia.org/wiki/Music">music</a> biography <a title="Television" href="http://en.wikipedia.org/wiki/Television">television</a> series on <a title="VH1" href="http://en.wikipedia.org/wiki/VH1">VH1</a>. Originally sponsored by <a title="AT&amp;T Corporation" href="http://en.wikipedia.org/wiki/AT%26T_Corporation">AT&amp;T Corporation</a>,  this series documents those artists (living or dead) who have made a  significant contribution to music history to be profiled on the show (as  opposed to VH1''s companion series, <i><a class="mw-redirect" title="Behind The Music" href="http://en.wikipedia.org/wiki/Behind_The_Music">Behind The Music</a></i>, which profiles mostly moderately significant artists).</p>\r\n<p>The show goes in-depth into the entire career of the artist(s), with  each episode containing rare concert and music video footage.</p>\r\n<p>The initial episodes were narrated by <a title="Kris Kristofferson" href="http://en.wikipedia.org/wiki/Kris_Kristofferson">Kris Kristofferson</a>, however other narrators have included <a title="Sheryl Crow" href="http://en.wikipedia.org/wiki/Sheryl_Crow">Sheryl Crow</a>, <a title="Steven Tyler" href="http://en.wikipedia.org/wiki/Steven_Tyler">Steven Tyler</a> (of <a title="Aerosmith" href="http://en.wikipedia.org/wiki/Aerosmith">Aerosmith</a>), <a title="Ossie Davis" href="http://en.wikipedia.org/wiki/Ossie_Davis">Ossie Davis</a>, <a title="Levon Helm" href="http://en.wikipedia.org/wiki/Levon_Helm">Levon Helm</a>, <a title="Henry Rollins" href="http://en.wikipedia.org/wiki/Henry_Rollins">Henry Rollins</a> and <a title="James Justice" href="http://en.wikipedia.org/wiki/James_Justice">James Justice</a>. Recent episodes have been hosted by <a title="William Baldwin" href="http://en.wikipedia.org/wiki/William_Baldwin">William Baldwin</a> (husband of singer <a title="Chynna Phillips" href="http://en.wikipedia.org/wiki/Chynna_Phillips">Chynna Phillips</a>).</p>', '<p><b>Legends</b> (aka <b>VH1''s Legends</b>) is a <a title="Music" href="http://en.wikipedia.org/wiki/Music">music</a> biography <a title="Television" href="http://en.wikipedia.org/wiki/Television">television</a> series on <a title="VH1" href="http://en.wikipedia.org/wiki/VH1">VH1</a>. Originally sponsored by <a title="AT&amp;T Corporation" href="http://en.wikipedia.org/wiki/AT%26T_Corporation">AT&amp;T Corporation</a>,  this series documents those artists (living or dead) who have made a  significant contribution to music history to be profiled on the show (as  opposed to VH1''s companion series, <i><a class="mw-redirect" title="Behind The Music" href="http://en.wikipedia.org/wiki/Behind_The_Music">Behind The Music</a></i>, which profiles mostly moderately significant artists).</p>\r\n<p>The show goes in-depth into the entire career of the artist(s), with  each episode containing rare concert and music video footage.</p>\r\n<p>The initial episodes were narrated by <a title="Kris Kristofferson" href="http://en.wikipedia.org/wiki/Kris_Kristofferson">Kris Kristofferson</a>, however other narrators have included <a title="Sheryl Crow" href="http://en.wikipedia.org/wiki/Sheryl_Crow">Sheryl Crow</a>, <a title="Steven Tyler" href="http://en.wikipedia.org/wiki/Steven_Tyler">Steven Tyler</a> (of <a title="Aerosmith" href="http://en.wikipedia.org/wiki/Aerosmith">Aerosmith</a>), <a title="Ossie Davis" href="http://en.wikipedia.org/wiki/Ossie_Davis">Ossie Davis</a>, <a title="Levon Helm" href="http://en.wikipedia.org/wiki/Levon_Helm">Levon Helm</a>, <a title="Henry Rollins" href="http://en.wikipedia.org/wiki/Henry_Rollins">Henry Rollins</a> and <a title="James Justice" href="http://en.wikipedia.org/wiki/James_Justice">James Justice</a>. Recent episodes have been hosted by <a title="William Baldwin" href="http://en.wikipedia.org/wiki/William_Baldwin">William Baldwin</a> (husband of singer <a title="Chynna Phillips" href="http://en.wikipedia.org/wiki/Chynna_Phillips">Chynna Phillips</a>).</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p><b>Legends</b> (aka <b>VH1''s Legends</b>) is a <a title="Music" href="http://en.wikipedia.org/wiki/Music">music</a> biography <a title="Television" href="http://en.wikipedia.org/wiki/Television">television</a> series on <a title="VH1" href="http://en.wikipedia.org/wiki/VH1">VH1</a>. Originally sponsored by <a title="AT&amp;T Corporation" href="http://en.wikipedia.org/wiki/AT%26T_Corporation">AT&amp;T Corporation</a>,  this series documents those artists (living or dead) who have made a  significant contribution to music history to be profiled on the show (as  opposed to VH1''s companion series, <i><a class="mw-redirect" title="Behind The Music" href="http://en.wikipedia.org/wiki/Behind_The_Music">Behind The Music</a></i>, which profiles mostly moderately significant artists).</p>\r\n<p>The show goes in-depth into the entire career of the artist(s), with  each episode containing rare concert and music video footage.</p>\r\n<p>The initial episodes were narrated by <a title="Kris Kristofferson" href="http://en.wikipedia.org/wiki/Kris_Kristofferson">Kris Kristofferson</a>, however other narrators have included <a title="Sheryl Crow" href="http://en.wikipedia.org/wiki/Sheryl_Crow">Sheryl Crow</a>, <a title="Steven Tyler" href="http://en.wikipedia.org/wiki/Steven_Tyler">Steven Tyler</a> (of <a title="Aerosmith" href="http://en.wikipedia.org/wiki/Aerosmith">Aerosmith</a>), <a title="Ossie Davis" href="http://en.wikipedia.org/wiki/Ossie_Davis">Ossie Davis</a>, <a title="Levon Helm" href="http://en.wikipedia.org/wiki/Levon_Helm">Levon Helm</a>, <a title="Henry Rollins" href="http://en.wikipedia.org/wiki/Henry_Rollins">Henry Rollins</a> and <a title="James Justice" href="http://en.wikipedia.org/wiki/James_Justice">James Justice</a>. Recent episodes have been hosted by <a title="William Baldwin" href="http://en.wikipedia.org/wiki/William_Baldwin">William Baldwin</a> (husband of singer <a title="Chynna Phillips" href="http://en.wikipedia.org/wiki/Chynna_Phillips">Chynna Phillips</a>).</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p><b>Legends</b> (aka <b>VH1''s Legends</b>) is a <a title="Music" href="http://en.wikipedia.org/wiki/Music">music</a> biography <a title="Television" href="http://en.wikipedia.org/wiki/Television">television</a> series on <a title="VH1" href="http://en.wikipedia.org/wiki/VH1">VH1</a>. Originally sponsored by <a title="AT&amp;T Corporation" href="http://en.wikipedia.org/wiki/AT%26T_Corporation">AT&amp;T Corporation</a>,  this series documents those artists (living or dead) who have made a  significant contribution to music history to be profiled on the show (as  opposed to VH1''s companion series, <i><a class="mw-redirect" title="Behind The Music" href="http://en.wikipedia.org/wiki/Behind_The_Music">Behind The Music</a></i>, which profiles mostly moderately significant artists).</p>\r\n<p>The show goes in-depth into the entire career of the artist(s), with  each episode containing rare concert and music video footage.</p>\r\n<p>The initial episodes were narrated by <a title="Kris Kristofferson" href="http://en.wikipedia.org/wiki/Kris_Kristofferson">Kris Kristofferson</a>, however other narrators have included <a title="Sheryl Crow" href="http://en.wikipedia.org/wiki/Sheryl_Crow">Sheryl Crow</a>, <a title="Steven Tyler" href="http://en.wikipedia.org/wiki/Steven_Tyler">Steven Tyler</a> (of <a title="Aerosmith" href="http://en.wikipedia.org/wiki/Aerosmith">Aerosmith</a>), <a title="Ossie Davis" href="http://en.wikipedia.org/wiki/Ossie_Davis">Ossie Davis</a>, <a title="Levon Helm" href="http://en.wikipedia.org/wiki/Levon_Helm">Levon Helm</a>, <a title="Henry Rollins" href="http://en.wikipedia.org/wiki/Henry_Rollins">Henry Rollins</a> and <a title="James Justice" href="http://en.wikipedia.org/wiki/James_Justice">James Justice</a>. Recent episodes have been hosted by <a title="William Baldwin" href="http://en.wikipedia.org/wiki/William_Baldwin">William Baldwin</a> (husband of singer <a title="Chynna Phillips" href="http://en.wikipedia.org/wiki/Chynna_Phillips">Chynna Phillips</a>).</p>', 'Article1409224925_imagesdsd.jpg', 100, NULL, 0, 1, '2014-08-28 16:52:05'),
(129, 'user', 1233, '3000', 'Test Firest', '28', '<p style="box-sizing: border-box; margin: 0px 0px 10px; color: rgb(130, 133, 135); font-family: Raleway, sans-serif; font-size: 14px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 20px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);"><b style="box-sizing: border-box; font-weight: bold;">test Legends</b><span class="Apple-converted-space">&nbsp;</span>(aka<span class="Apple-converted-space">&nbsp;</span><b style="box-sizing: border-box; font-weight: bold;">VH1''s Legends</b>) is a<span class="Apple-converted-space">&nbsp;</span><a style="box-sizing: border-box; background-color: transparent; color: rgb(66, 139, 202); text-decoration: none; -webkit-transition: all 300ms; transition: all 300ms; background-position: initial initial; background-repeat: initial initial;" href="http://en.wikipedia.org/wiki/Music" title="Music">music</a><span class="Apple-converted-space">&nbsp;</span>biography<span class="Apple-converted-space">&nbsp;</span><a style="box-sizing: border-box; background-color: transparent; color: rgb(66, 139, 202); text-decoration: none; -webkit-transition: all 300ms; transition: all 300ms; background-position: initial initial; background-repeat: initial initial;" href="http://en.wikipedia.org/wiki/Television" title="Television">television</a><span class="Apple-converted-space">&nbsp;</span>series on<span class="Apple-converted-space">&nbsp;</span><a style="box-sizing: border-box; background-color: transparent; color: rgb(66, 139, 202); text-decoration: none; -webkit-transition: all 300ms; transition: all 300ms; background-position: initial initial; background-repeat: initial initial;" href="http://en.wikipedia.org/wiki/VH1" title="VH1">VH1</a>. Originally sponsored by<span class="Apple-converted-space">&nbsp;</span><a style="box-sizing: border-box; background-color: transparent; color: rgb(66, 139, 202); text-decoration: none; -webkit-transition: all 300ms; transition: all 300ms; background-position: initial initial; background-repeat: initial initial;" href="http://en.wikipedia.org/wiki/AT%26T_Corporation" title="AT&amp;T Corporation">AT&amp;T Corporation</a>, this series documents those artists (living or dead) who have made a significant contribution to music history to be profiled on the show (as opposed to VH1''s companion series,<span class="Apple-converted-space">&nbsp;</span><i style="box-sizing: border-box;"><a style="box-sizing: border-box; background-color: transparent; color: rgb(66, 139, 202); text-decoration: none; -webkit-transition: all 300ms; transition: all 300ms; background-position: initial initial; background-repeat: initial initial;" href="http://en.wikipedia.org/wiki/Behind_The_Music" title="Behind The Music" class="mw-redirect">Behind The Music</a></i>, which profiles mostly moderately significant artists).</p>\r\n<p style="box-sizing: border-box; margin: 0px 0px 10px; color: rgb(130, 133, 135); font-family: Raleway, sans-serif; font-size: 14px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 20px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);">The show goes in-depth into the entire career of the artist(s), with each episode containing rare concert and music video footage.</p>\r\n<p style="box-sizing: border-box; margin: 0px 0px 10px; color: rgb(130, 133, 135); font-family: Raleway, sans-serif; font-size: 14px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 20px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);">The initial episodes were narrated by<span class="Apple-converted-space">&nbsp;</span><a style="box-sizing: border-box; background-color: transparent; color: rgb(66, 139, 202); text-decoration: none; -webkit-transition: all 300ms; transition: all 300ms; background-position: initial initial; background-repeat: initial initial;" href="http://en.wikipedia.org/wiki/Kris_Kristofferson" title="Kris Kristofferson">Kris Kristofferson</a>, however other narrators have included<span class="Apple-converted-space">&nbsp;</span><a style="box-sizing: border-box; background-color: transparent; color: rgb(66, 139, 202); text-decoration: none; -webkit-transition: all 300ms; transition: all 300ms; background-position: initial initial; background-repeat: initial initial;" href="http://en.wikipedia.org/wiki/Sheryl_Crow" title="Sheryl Crow">Sheryl Crow</a>,<span class="Apple-converted-space">&nbsp;</span><a style="box-sizing: border-box; background-color: transparent; color: rgb(66, 139, 202); text-decoration: none; -webkit-transition: all 300ms; transition: all 300ms; background-position: initial initial; background-repeat: initial initial;" href="http://en.wikipedia.org/wiki/Steven_Tyler" title="Steven Tyler">Steven Tyler</a><span class="Apple-converted-space">&nbsp;</span>(of<span class="Apple-converted-space">&nbsp;</span><a style="box-sizing: border-box; background-color: transparent; color: rgb(66, 139, 202); text-decoration: none; -webkit-transition: all 300ms; transition: all 300ms; background-position: initial initial; background-repeat: initial initial;" href="http://en.wikipedia.org/wiki/Aerosmith" title="Aerosmith">Aerosmith</a>),<span class="Apple-converted-space">&nbsp;</span><a style="box-sizing: border-box; background-color: transparent; color: rgb(66, 139, 202); text-decoration: none; -webkit-transition: all 300ms; transition: all 300ms; background-position: initial initial; background-repeat: initial initial;" href="http://en.wikipedia.org/wiki/Ossie_Davis" title="Ossie Davis">Ossie Davis</a>,<span class="Apple-converted-space">&nbsp;</span><a style="box-sizing: border-box; background-color: transparent; color: rgb(66, 139, 202); text-decoration: none; -webkit-transition: all 300ms; transition: all 300ms; background-position: initial initial; background-repeat: initial initial;" href="http://en.wikipedia.org/wiki/Levon_Helm" title="Levon Helm">Levon Helm</a>,<span class="Apple-converted-space">&nbsp;</span><a style="box-sizing: border-box; background-color: transparent; color: rgb(66, 139, 202); text-decoration: none; -webkit-transition: all 300ms; transition: all 300ms; background-position: initial initial; background-repeat: initial initial;" href="http://en.wikipedia.org/wiki/Henry_Rollins" title="Henry Rollins">Henry Rollins</a>and<span class="Apple-converted-space">&nbsp;</span><a style="box-sizing: border-box; background-color: transparent; color: rgb(66, 139, 202); text-decoration: none; -webkit-transition: all 300ms; transition: all 300ms; background-position: initial initial; background-repeat: initial initial;" href="http://en.wikipedia.org/wiki/James_Justice" title="James Justice">James Justice</a>. Recent episodes have been hosted by<span class="Apple-converted-space">&nbsp;</span><a style="box-sizing: border-box; background-color: transparent; color: rgb(66, 139, 202); text-decoration: none; -webkit-transition: all 300ms; transition: all 300ms; background-position: initial initial; background-repeat: initial initial;" href="http://en.wikipedia.org/wiki/William_Baldwin" title="William Baldwin">William Baldwin</a><span class="Apple-converted-space">&nbsp;</span>(husband of singer<span class="Apple-converted-space">&nbsp;</span><a style="box-sizing: border-box; background-color: transparent; color: rgb(66, 139, 202); text-decoration: none; -webkit-transition: all 300ms; transition: all 300ms; background-position: initial initial; background-repeat: initial initial;" href="http://en.wikipedia.org/wiki/Chynna_Phillips" title="Chynna Phillips">Chynna Phillips</a>).</p>', '<p style="box-sizing: border-box; margin: 0px 0px 10px; color: rgb(130, 133, 135); font-family: Raleway, sans-serif; font-size: 14px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 20px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);"><b style="box-sizing: border-box; font-weight: bold;">Legends</b><span class="Apple-converted-space">&nbsp;</span>(aka<span class="Apple-converted-space">&nbsp;</span><b style="box-sizing: border-box; font-weight: bold;">VH1''s Legends</b>) is a<span class="Apple-converted-space">&nbsp;</span><a style="box-sizing: border-box; background-color: transparent; color: rgb(66, 139, 202); text-decoration: none; -webkit-transition: all 300ms; transition: all 300ms; background-position: initial initial; background-repeat: initial initial;" href="http://en.wikipedia.org/wiki/Music" title="Music">music</a><span class="Apple-converted-space">&nbsp;</span>biography<span class="Apple-converted-space">&nbsp;</span><a style="box-sizing: border-box; background-color: transparent; color: rgb(66, 139, 202); text-decoration: none; -webkit-transition: all 300ms; transition: all 300ms; background-position: initial initial; background-repeat: initial initial;" href="http://en.wikipedia.org/wiki/Television" title="Television">television</a><span class="Apple-converted-space">&nbsp;</span>series on<span class="Apple-converted-space">&nbsp;</span><a style="box-sizing: border-box; background-color: transparent; color: rgb(66, 139, 202); text-decoration: none; -webkit-transition: all 300ms; transition: all 300ms; background-position: initial initial; background-repeat: initial initial;" href="http://en.wikipedia.org/wiki/VH1" title="VH1">VH1</a>. Originally sponsored by<span class="Apple-converted-space">&nbsp;</span><a style="box-sizing: border-box; background-color: transparent; color: rgb(66, 139, 202); text-decoration: none; -webkit-transition: all 300ms; transition: all 300ms; background-position: initial initial; background-repeat: initial initial;" href="http://en.wikipedia.org/wiki/AT%26T_Corporation" title="AT&amp;T Corporation">AT&amp;T Corporation</a>, this series documents those artists (living or dead) who have made a significant contribution to music history to be profiled on the show (as opposed to VH1''s companion series,<span class="Apple-converted-space">&nbsp;</span><i style="box-sizing: border-box;"><a style="box-sizing: border-box; background-color: transparent; color: rgb(66, 139, 202); text-decoration: none; -webkit-transition: all 300ms; transition: all 300ms; background-position: initial initial; background-repeat: initial initial;" href="http://en.wikipedia.org/wiki/Behind_The_Music" title="Behind The Music" class="mw-redirect">Behind The Music</a></i>, which profiles mostly moderately significant artists).</p>\r\n<p style="box-sizing: border-box; margin: 0px 0px 10px; color: rgb(130, 133, 135); font-family: Raleway, sans-serif; font-size: 14px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 20px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);">The show goes in-depth into the entire career of the artist(s), with each episode containing rare concert and music video footage.</p>\r\n<p style="box-sizing: border-box; margin: 0px 0px 10px; color: rgb(130, 133, 135); font-family: Raleway, sans-serif; font-size: 14px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 20px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);">The initial episodes were narrated by<span class="Apple-converted-space">&nbsp;</span><a style="box-sizing: border-box; background-color: transparent; color: rgb(66, 139, 202); text-decoration: none; -webkit-transition: all 300ms; transition: all 300ms; background-position: initial initial; background-repeat: initial initial;" href="http://en.wikipedia.org/wiki/Kris_Kristofferson" title="Kris Kristofferson">Kris Kristofferson</a>, however other narrators have included<span class="Apple-converted-space">&nbsp;</span><a style="box-sizing: border-box; background-color: transparent; color: rgb(66, 139, 202); text-decoration: none; -webkit-transition: all 300ms; transition: all 300ms; background-position: initial initial; background-repeat: initial initial;" href="http://en.wikipedia.org/wiki/Sheryl_Crow" title="Sheryl Crow">Sheryl Crow</a>,<span class="Apple-converted-space">&nbsp;</span><a style="box-sizing: border-box; background-color: transparent; color: rgb(66, 139, 202); text-decoration: none; -webkit-transition: all 300ms; transition: all 300ms; background-position: initial initial; background-repeat: initial initial;" href="http://en.wikipedia.org/wiki/Steven_Tyler" title="Steven Tyler">Steven Tyler</a><span class="Apple-converted-space">&nbsp;</span>(of<span class="Apple-converted-space">&nbsp;</span><a style="box-sizing: border-box; background-color: transparent; color: rgb(66, 139, 202); text-decoration: none; -webkit-transition: all 300ms; transition: all 300ms; background-position: initial initial; background-repeat: initial initial;" href="http://en.wikipedia.org/wiki/Aerosmith" title="Aerosmith">Aerosmith</a>),<span class="Apple-converted-space">&nbsp;</span><a style="box-sizing: border-box; background-color: transparent; color: rgb(66, 139, 202); text-decoration: none; -webkit-transition: all 300ms; transition: all 300ms; background-position: initial initial; background-repeat: initial initial;" href="http://en.wikipedia.org/wiki/Ossie_Davis" title="Ossie Davis">Ossie Davis</a>,<span class="Apple-converted-space">&nbsp;</span><a style="box-sizing: border-box; background-color: transparent; color: rgb(66, 139, 202); text-decoration: none; -webkit-transition: all 300ms; transition: all 300ms; background-position: initial initial; background-repeat: initial initial;" href="http://en.wikipedia.org/wiki/Levon_Helm" title="Levon Helm">Levon Helm</a>,<span class="Apple-converted-space">&nbsp;</span><a style="box-sizing: border-box; background-color: transparent; color: rgb(66, 139, 202); text-decoration: none; -webkit-transition: all 300ms; transition: all 300ms; background-position: initial initial; background-repeat: initial initial;" href="http://en.wikipedia.org/wiki/Henry_Rollins" title="Henry Rollins">Henry Rollins</a>and<span class="Apple-converted-space">&nbsp;</span><a style="box-sizing: border-box; background-color: transparent; color: rgb(66, 139, 202); text-decoration: none; -webkit-transition: all 300ms; transition: all 300ms; background-position: initial initial; background-repeat: initial initial;" href="http://en.wikipedia.org/wiki/James_Justice" title="James Justice">James Justice</a>. Recent episodes have been hosted by<span class="Apple-converted-space">&nbsp;</span><a style="box-sizing: border-box; background-color: transparent; color: rgb(66, 139, 202); text-decoration: none; -webkit-transition: all 300ms; transition: all 300ms; background-position: initial initial; background-repeat: initial initial;" href="http://en.wikipedia.org/wiki/William_Baldwin" title="William Baldwin">William Baldwin</a><span class="Apple-converted-space">&nbsp;</span>(husband of singer<span class="Apple-converted-space">&nbsp;</span><a style="box-sizing: border-box; background-color: transparent; color: rgb(66, 139, 202); text-decoration: none; -webkit-transition: all 300ms; transition: all 300ms; background-position: initial initial; background-repeat: initial initial;" href="http://en.wikipedia.org/wiki/Chynna_Phillips" title="Chynna Phillips">Chynna Phillips</a>).</p>\r\n<p style="box-sizing: border-box; margin: 0px 0px 10px; color: rgb(130, 133, 135); font-family: Raleway, sans-serif; font-size: 14px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 20px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);"><b style="box-sizing: border-box; font-weight: bold;">Legends</b><span class="Apple-converted-space">&nbsp;</span>(aka<span class="Apple-converted-space">&nbsp;</span><b style="box-sizing: border-box; font-weight: bold;">VH1''s Legends</b>) is a<span class="Apple-converted-space">&nbsp;</span><a style="box-sizing: border-box; background-color: transparent; color: rgb(66, 139, 202); text-decoration: none; -webkit-transition: all 300ms; transition: all 300ms; background-position: initial initial; background-repeat: initial initial;" href="http://en.wikipedia.org/wiki/Music" title="Music">music</a><span class="Apple-converted-space">&nbsp;</span>biography<span class="Apple-converted-space">&nbsp;</span><a style="box-sizing: border-box; background-color: transparent; color: rgb(66, 139, 202); text-decoration: none; -webkit-transition: all 300ms; transition: all 300ms; background-position: initial initial; background-repeat: initial initial;" href="http://en.wikipedia.org/wiki/Television" title="Television">television</a><span class="Apple-converted-space">&nbsp;</span>series on<span class="Apple-converted-space">&nbsp;</span><a style="box-sizing: border-box; background-color: transparent; color: rgb(66, 139, 202); text-decoration: none; -webkit-transition: all 300ms; transition: all 300ms; background-position: initial initial; background-repeat: initial initial;" href="http://en.wikipedia.org/wiki/VH1" title="VH1">VH1</a>. Originally sponsored by<span class="Apple-converted-space">&nbsp;</span><a style="box-sizing: border-box; background-color: transparent; color: rgb(66, 139, 202); text-decoration: none; -webkit-transition: all 300ms; transition: all 300ms; background-position: initial initial; background-repeat: initial initial;" href="http://en.wikipedia.org/wiki/AT%26T_Corporation" title="AT&amp;T Corporation">AT&amp;T Corporation</a>, this series documents those artists (living or dead) who have made a significant contribution to music history to be profiled on the show (as opposed to VH1''s companion series,<span class="Apple-converted-space">&nbsp;</span><i style="box-sizing: border-box;"><a style="box-sizing: border-box; background-color: transparent; color: rgb(66, 139, 202); text-decoration: none; -webkit-transition: all 300ms; transition: all 300ms; background-position: initial initial; background-repeat: initial initial;" href="http://en.wikipedia.org/wiki/Behind_The_Music" title="Behind The Music" class="mw-redirect">Behind The Music</a></i>, which profiles mostly moderately significant artists).</p>\r\n<p style="box-sizing: border-box; margin: 0px 0px 10px; color: rgb(130, 133, 135); font-family: Raleway, sans-serif; font-size: 14px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 20px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);">The show goes in-depth into the entire career of the artist(s), with each episode containing rare concert and music video footage.</p>\r\n<p style="box-sizing: border-box; margin: 0px 0px 10px; color: rgb(130, 133, 135); font-family: Raleway, sans-serif; font-size: 14px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 20px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);">The initial episodes were narrated by<span class="Apple-converted-space">&nbsp;</span><a style="box-sizing: border-box; background-color: transparent; color: rgb(66, 139, 202); text-decoration: none; -webkit-transition: all 300ms; transition: all 300ms; background-position: initial initial; background-repeat: initial initial;" href="http://en.wikipedia.org/wiki/Kris_Kristofferson" title="Kris Kristofferson">Kris Kristofferson</a>, however other narrators have included<span class="Apple-converted-space">&nbsp;</span><a style="box-sizing: border-box; background-color: transparent; color: rgb(66, 139, 202); text-decoration: none; -webkit-transition: all 300ms; transition: all 300ms; background-position: initial initial; background-repeat: initial initial;" href="http://en.wikipedia.org/wiki/Sheryl_Crow" title="Sheryl Crow">Sheryl Crow</a>,<span class="Apple-converted-space">&nbsp;</span><a style="box-sizing: border-box; background-color: transparent; color: rgb(66, 139, 202); text-decoration: none; -webkit-transition: all 300ms; transition: all 300ms; background-position: initial initial; background-repeat: initial initial;" href="http://en.wikipedia.org/wiki/Steven_Tyler" title="Steven Tyler">Steven Tyler</a><span class="Apple-converted-space">&nbsp;</span>(of<span class="Apple-converted-space">&nbsp;</span><a style="box-sizing: border-box; background-color: transparent; color: rgb(66, 139, 202); text-decoration: none; -webkit-transition: all 300ms; transition: all 300ms; background-position: initial initial; background-repeat: initial initial;" href="http://en.wikipedia.org/wiki/Aerosmith" title="Aerosmith">Aerosmith</a>),<span class="Apple-converted-space">&nbsp;</span><a style="box-sizing: border-box; background-color: transparent; color: rgb(66, 139, 202); text-decoration: none; -webkit-transition: all 300ms; transition: all 300ms; background-position: initial initial; background-repeat: initial initial;" href="http://en.wikipedia.org/wiki/Ossie_Davis" title="Ossie Davis">Ossie Davis</a>,<span class="Apple-converted-space">&nbsp;</span><a style="box-sizing: border-box; background-color: transparent; color: rgb(66, 139, 202); text-decoration: none; -webkit-transition: all 300ms; transition: all 300ms; background-position: initial initial; background-repeat: initial initial;" href="http://en.wikipedia.org/wiki/Levon_Helm" title="Levon Helm">Levon Helm</a>,<span class="Apple-converted-space">&nbsp;</span><a style="box-sizing: border-box; background-color: transparent; color: rgb(66, 139, 202); text-decoration: none; -webkit-transition: all 300ms; transition: all 300ms; background-position: initial initial; background-repeat: initial initial;" href="http://en.wikipedia.org/wiki/Henry_Rollins" title="Henry Rollins">Henry Rollins</a>and<span class="Apple-converted-space">&nbsp;</span><a style="box-sizing: border-box; background-color: transparent; color: rgb(66, 139, 202); text-decoration: none; -webkit-transition: all 300ms; transition: all 300ms; background-position: initial initial; background-repeat: initial initial;" href="http://en.wikipedia.org/wiki/James_Justice" title="James Justice">James Justice</a>. Recent episodes have been hosted by<span class="Apple-converted-space">&nbsp;</span><a style="box-sizing: border-box; background-color: transparent; color: rgb(66, 139, 202); text-decoration: none; -webkit-transition: all 300ms; transition: all 300ms; background-position: initial initial; background-repeat: initial initial;" href="http://en.wikipedia.org/wiki/William_Baldwin" title="William Baldwin">William Baldwin</a><span class="Apple-converted-space">&nbsp;</span>(husband of singer<span class="Apple-converted-space">&nbsp;</span><a style="box-sizing: border-box; background-color: transparent; color: rgb(66, 139, 202); text-decoration: none; -webkit-transition: all 300ms; transition: all 300ms; background-position: initial initial; background-repeat: initial initial;" href="http://en.wikipedia.org/wiki/Chynna_Phillips" title="Chynna Phillips">Chynna Phillips</a>).</p>', 'Article1409289473_category-listing-banner.png', 0, NULL, 1, 0, '2014-08-29 10:47:53'),
(130, 'user', 1985, '7000', 'Fundraiser for Classical Musicians', '28', '<p><a href="http://www.google.com">www.google.com</a></p>\r\n<p>&nbsp;</p>\r\n<p>Fundraiser for Classical MusiciansFundraiser for Classical MusiciansFundraiser for Classical MusiciansFundraiser for Classical MusiciansFundraiser for Classical MusiciansFundraiser for Classical MusiciansFundraiser for Classical MusiciansFundraiser for Classical Musicians</p>\r\n<p>&nbsp;</p>\r\n<p>Fundraiser for Classical MusiciansFundraiser for Classical MusiciansFundraiser for Classical Musicians</p>', '<p><span style="color: rgb(255, 0, 0);">Fundraiser for Classical MusiciansFundraiser for Classical Musicians Fundraiser for Classical MusiciansFundraiser for Classical MusiciansFundraiser for Classical MusiciansFundraiser for Classical MusiciansFundraiser for Classical MusiciansFundraiser for Classical MusiciansFundraiser for Classical Musicians<br />\r\n</span></p>\r\n<p><span style="color: rgb(255, 0, 0);"><br />\r\n</span></p>\r\n<p><span style="color: rgb(255, 0, 0);"><br />\r\n</span></p>\r\n<p><span style="color: rgb(255, 0, 0);">Fundraiser for Classical MusiciansFundraiser for Classical MusiciansFundraiser for Classical MusiciansFundraiser for Classical MusiciansFundraiser for Classical MusiciansFundraiser for Classical Musicians<br />\r\n</span></p>', 'Article1409293832_index - Copy (3).jpg', 0, NULL, 1, 1, '2014-08-29 12:00:32'),
(138, 'admin', 1, '3000', 'Test Firest demo', '37', 'test', 'test', 'Article1409722469_article-image.png', 0, NULL, 0, 1, '2014-09-03 11:04:29');
INSERT INTO `articles` (`id`, `author`, `user_id`, `amount`, `title`, `category`, `summary`, `description`, `image`, `totaldonation`, `press`, `publicprivate`, `status`, `date`) VALUES
(139, 'user', 1986, '9999', 'deepak first article', '39', '<p><b style="box-sizing: border-box; font-weight: bold;">Legends</b><span class="Apple-converted-space">&nbsp;</span>(aka<span class="Apple-converted-space">&nbsp;</span><b style="box-sizing: border-box; font-weight: bold;">VH1''s Legends</b>) is a<span class="Apple-converted-space">&nbsp;</span><a title="Music" href="http://en.wikipedia.org/wiki/Music" style="box-sizing: border-box; background-color: transparent; color: rgb(66, 139, 202); text-decoration: none; -webkit-transition: all 300ms; transition: all 300ms; background-position: initial initial; background-repeat: initial initial;">music</a><span class="Apple-converted-space">&nbsp;</span>biography<span class="Apple-converted-space">&nbsp;</span><a title="Television" href="http://en.wikipedia.org/wiki/Television" style="box-sizing: border-box; background-color: transparent; color: rgb(66, 139, 202); text-decoration: none; -webkit-transition: all 300ms; transition: all 300ms; background-position: initial initial; background-repeat: initial initial;">television</a><span class="Apple-converted-space">&nbsp;</span>series on<span class="Apple-converted-space">&nbsp;</span><a title="VH1" href="http://en.wikipedia.org/wiki/VH1" style="box-sizing: border-box; background-color: transparent; color: rgb(66, 139, 202); text-decoration: none; -webkit-transition: all 300ms; transition: all 300ms; background-position: initial initial; background-repeat: initial initial;">VH1</a>. Originally sponsored by<span class="Apple-converted-space">&nbsp;</span><a title="AT&amp;T Corporation" href="http://en.wikipedia.org/wiki/AT%26T_Corporation" style="box-sizing: border-box; background-color: transparent; color: rgb(66, 139, 202); text-decoration: none; -webkit-transition: all 300ms; transition: all 300ms; background-position: initial initial; background-repeat: initial initial;">AT&amp;T Corporation</a>,  this series documents those artists (living or dead) who have made a  significant contribution to music history to be profiled on the show (as  opposed to VH1''s companion series,<span class="Apple-converted-space">&nbsp;</span><i style="box-sizing: border-box;"><a class="mw-redirect" title="Behind The Music" href="http://en.wikipedia.org/wiki/Behind_The_Music" style="box-sizing: border-box; background-color: transparent; color: rgb(66, 139, 202); text-decoration: none; -webkit-transition: all 300ms; transition: all 300ms; background-position: initial initial; background-repeat: initial initial;">Behind The Music</a></i>, which profiles mostly moderately significant artists).</p>', '<p><b style="box-sizing: border-box; font-weight: bold;">Legends</b><span class="Apple-converted-space">&nbsp;</span>(aka<span class="Apple-converted-space">&nbsp;</span><b style="box-sizing: border-box; font-weight: bold;">VH1''s Legends</b>) is a<span class="Apple-converted-space">&nbsp;</span><a title="Music" href="http://en.wikipedia.org/wiki/Music" style="box-sizing: border-box; background-color: transparent; color: rgb(66, 139, 202); text-decoration: none; -webkit-transition: all 300ms; transition: all 300ms; background-position: initial initial; background-repeat: initial initial;">music</a><span class="Apple-converted-space">&nbsp;</span>biography<span class="Apple-converted-space">&nbsp;</span><a title="Television" href="http://en.wikipedia.org/wiki/Television" style="box-sizing: border-box; background-color: transparent; color: rgb(66, 139, 202); text-decoration: none; -webkit-transition: all 300ms; transition: all 300ms; background-position: initial initial; background-repeat: initial initial;">television</a><span class="Apple-converted-space">&nbsp;</span>series on<span class="Apple-converted-space">&nbsp;</span><a title="VH1" href="http://en.wikipedia.org/wiki/VH1" style="box-sizing: border-box; background-color: transparent; color: rgb(66, 139, 202); text-decoration: none; -webkit-transition: all 300ms; transition: all 300ms; background-position: initial initial; background-repeat: initial initial;">VH1</a>. Originally sponsored by<span class="Apple-converted-space">&nbsp;</span><a title="AT&amp;T Corporation" href="http://en.wikipedia.org/wiki/AT%26T_Corporation" style="box-sizing: border-box; background-color: transparent; color: rgb(66, 139, 202); text-decoration: none; -webkit-transition: all 300ms; transition: all 300ms; background-position: initial initial; background-repeat: initial initial;">AT&amp;T Corporation</a>,  this series documents those artists (living or dead) who have made a  significant contribution to music history to be profiled on the show (as  opposed to VH1''s companion series,<span class="Apple-converted-space">&nbsp;</span><i style="box-sizing: border-box;"><a class="mw-redirect" title="Behind The Music" href="http://en.wikipedia.org/wiki/Behind_The_Music" style="box-sizing: border-box; background-color: transparent; color: rgb(66, 139, 202); text-decoration: none; -webkit-transition: all 300ms; transition: all 300ms; background-position: initial initial; background-repeat: initial initial;">Behind The Music</a></i>, which profiles mostly moderately significant artists).</p>', 'Article1410328472_article-image-2.png', 0, NULL, 0, 1, '2014-09-10 11:24:32'),
(140, 'user', 1234, '10000', 'Megadeth Fundraiser.', '39', '<p><b>Megadeth</b> is a <a title="Thrash metal" href="http://en.wikipedia.org/wiki/Thrash_metal">thrash metal</a> band from <a title="Los Angeles" href="http://en.wikipedia.org/wiki/Los_Angeles">Los Angeles</a>, California. The group was formed in 1983 by guitarist <a title="Dave Mustaine" href="http://en.wikipedia.org/wiki/Dave_Mustaine">Dave Mustaine</a> and bassist <a title="David Ellefson" href="http://en.wikipedia.org/wiki/David_Ellefson">David Ellefson</a>, shortly after Mustaine''s dismissal from <a title="Metallica" href="http://en.wikipedia.org/wiki/Metallica">Metallica</a>. A pioneer of the American thrash metal scene, the band is credited as one of the genre''s &quot;big four&quot; with <a title="Anthrax (American band)" href="http://en.wikipedia.org/wiki/Anthrax_%28American_band%29">Anthrax</a>, Metallica and <a title="Slayer" href="http://en.wikipedia.org/wiki/Slayer">Slayer</a>,  responsible for thrash metal''s development and popularization. Megadeth  plays in a technical style, featuring fast rhythm sections and complex  arrangements; themes of death, war, politics and religion are prominent  in the group''s lyrics.</p>', '<p>In 1985, the band released its debut album on the independent label <a title="Combat Records" href="http://en.wikipedia.org/wiki/Combat_Records">Combat Records</a>. The album''s moderate commercial success caught the attention of bigger labels, which led to Megadeth signing with <a title="Capitol Records" href="http://en.wikipedia.org/wiki/Capitol_Records">Capitol Records</a>. The band''s first major-label album, <i><a title="Peace Sells... but Who''s Buying?" href="http://en.wikipedia.org/wiki/Peace_Sells..._but_Who%27s_Buying%3F">Peace Sells... but Who''s Buying?</a></i>,  was released in 1986 and greatly influenced the underground metal  scene. Despite the album''s prominence in thrash metal, frequent disputes  between its members and substance abuse issues brought Megadeth  negative publicity during this period.</p>\r\n<p>After the lineup stabilized, the band released a number of <a title="Music recording sales certification" href="http://en.wikipedia.org/wiki/Music_recording_sales_certification">platinum-selling albums</a>, including <i><a title="Rust in Peace" href="http://en.wikipedia.org/wiki/Rust_in_Peace">Rust in Peace</a></i> (1990) and <i><a title="Countdown to Extinction" href="http://en.wikipedia.org/wiki/Countdown_to_Extinction">Countdown to Extinction</a></i>  (1992). These albums, along with touring worldwide, helped bring public  recognition to Megadeth. The band temporarily disbanded in 2002 when  Mustaine suffered an arm injury and re-established in 2004 without  bassist Ellefson, who had taken legal action against Mustaine. Ellefson  settled with Mustaine out of court and rejoined the group in 2010.  Megadeth has hosted its own music festival, <a title="Gigantour" href="http://en.wikipedia.org/wiki/Gigantour">Gigantour</a>, several times since mid-2005.</p>\r\n<p>As of 2014, Megadeth has sold 50 million records worldwide, earned  platinum certification in the United States for six of its fourteen  studio albums, and received eleven <a title="Grammy Award" href="http://en.wikipedia.org/wiki/Grammy_Award">Grammy nominations</a>. The band''s mascot, <a title="Vic Rattlehead" href="http://en.wikipedia.org/wiki/Vic_Rattlehead">Vic Rattlehead</a>,  regularly appears on album artwork and, since 2010, in live shows. The  group has experienced controversy over its musical approach and lyrics,  including canceled concerts and album bans. <a title="MTV" href="http://en.wikipedia.org/wiki/MTV">MTV</a> has refused to play two of the band''s videos that the network considered to condone suicide.</p>', 'Article1410419880_1024px-Megadeth2010.jpg', 11501, NULL, 0, 1, '2014-09-11 12:48:00'),
(141, 'user', 1248, '1500', 'VH1 music fundraiser', '27', '<p>VH1 music fundraiserVH1 music fundraiserVH1 music fundraiserVH1 music fundraiserVH1 music fundraiserVH1 music fundraiserVH1 music fundraiserVH1 music fundraiserVH1 music fundraiserVH1 music fundraiserVH1 music fundraiserVH1 music fundraiserVH1 music fundraiserVH1 music fundraiser</p>', '<p>VH1 music fundraiserVH1 music fundraiserVH1 music fundraiserVH1 music fundraiserVH1 music fundraiserVH1 music fundraiserVH1 music fundraiserVH1 music fundraiserVH1 music fundraiserVH1 music fundraiserVH1 music fundraiserVH1 music fundraiserVH1 music fundraiserVH1 music fundraiserVH1 music fundraiserVH1 music fundraiserVH1 music fundraiserVH1 music fundraiserVH1 music fundraiserVH1 music fundraiserVH1 music fundraiserVH1 music fundraiserVH1 music fundraiserVH1 music fundraiserVH1 music fundraiserVH1 music fundraiserVH1 music fundraiserVH1 music fundraiserVH1 music fundraiserVH1 music fundraiserVH1 music fundraiserVH1 music fundraiserVH1 music fundraiserVH1 music fundraiserVH1 music fundraiserVH1 music fundraiserVH1 music fundraiserVH1 music fundraiserVH1 music fundraiserVH1 music fundraiserVH1 music fundraiserVH1 music fundraiserVH1 music fundraiserVH1 music fundraiserVH1 music fundraiserVH1 music fundraiserVH1 music fundraiserVH1 music fundraiserVH1 music fundraiserVH1 music fundraiserVH1 music fundraiserVH1 music fundraiserVH1 music fundraiserVH1 music fundraiserVH1 music fundraiserVH1 music fundraiserVH1 music fundraiserVH1 music fundraiserVH1 music fundraiserVH1 music fundraiserVH1 music fundraiserVH1 music fundraiserVH1 music fundraiserVH1 music fundraiserVH1 music fundraiser</p>', 'Article1411384082_image002-732513.png', 3000, NULL, 1, 1, '2014-09-22 16:38:03'),
(142, 'user', 1214, '400', 'Second Article', '28', '<p>This is my Second articles.</p>\r\n', '<p>This is my Second articles.</p>\r\n', 'Article1412005801_canadian_brass-5222.jpg', 0, NULL, 0, 1, '2014-09-29 20:43:01'),
(143, 'user', 1216, '3000', 'Today Article', '37', '<p>Per a request, here&#39;s a simple class I threw together that lets you get City and State info (and longitude and latitude) from a zip code using Google&#39;s Geocoding REST API. Obviously, the accuracy of the longitude and latitude would be more accurate if you provide it an address, but here&#39;s how to do it. I assume you&#39;ve got the Zend Framework in your include path and can use Zend_Http_Client. You can get that here if you don&#39;t have it: <a href="http://framework.zend.com">http://framework.zend.com</a></p>\r\n\r\n<p>&nbsp;</p>\r\n', '<p>Per a request, here&#39;s a simple class I threw together that lets you get City and State info (and longitude and latitude) from a zip code using Google&#39;s Geocoding REST API. Obviously, the accuracy of the longitude and latitude would be more accurate if you provide it an address, but here&#39;s how to do it. I assume you&#39;ve got the Zend Framework in your include path and can use Zend_Http_Client. You can get that here if you don&#39;t have it: <a href="http://framework.zend.com">http://framework.zend.com</a></p>\r\n', 'Article1412945148_baby-boy-wearing-hat.jpg', 0, NULL, 0, 1, '2014-10-10 18:15:48'),
(144, 'user', 1216, '300', 'first test', '37', '<p>first test</p>\r\n', '<p>first test</p>\r\n', 'Article1413965078_user-register.png', 0, NULL, 0, 1, '2014-10-22 13:34:42'),
(145, 'user', 1216, '9000', 'test', '37', '<p>dsdsafd</p>\r\n', '<p>sfdfds</p>\r\n', 'Article1413965355_facebook_icon.png', 0, NULL, 0, 1, '2014-10-22 13:39:20'),
(146, 'user', 1216, '600', 'final test', '37', '<p>final test</p>\r\n', '<p>final test</p>\r\n', 'Article1413966201_banner_section_bottom.jpg', 0, NULL, 0, 1, '2014-10-22 13:53:35'),
(147, 'user', 1214, '90', 'test', '37', '<p>test</p>\r\n', '<p>test</p>\r\n', 'Article1413966344_main_slider_01.jpg', 0, NULL, 0, 1, '2014-10-22 13:55:56'),
(148, 'user', 1214, '30000', 'dsfdsfd', '37', '<p>dfdsf</p>\r\n', '<p>fdsfds</p>\r\n', 'Article1413968686_arrow-grey-orange.png', 0, NULL, 0, 1, '2014-10-22 14:35:00'),
(149, 'user', 1214, '500', 'sdsfsf', '37', '<p>dsfdsf</p>\r\n', '<p>fdsfdf</p>\r\n', 'Article1413968880_arrow_orange01.png', 0, NULL, 0, 1, '2014-10-22 14:38:12'),
(150, 'user', 1214, '633', 'testing', '37', '<p>testing</p>\r\n', '<p>testing</p>\r\n', 'Article1413971121_banner_section_bottom.jpg', 0, NULL, 0, 1, '2014-10-22 15:15:26'),
(151, 'user', 1214, '555', 'dfd', '37', '<p>fdgdfg</p>\r\n', '<p>fdgdfg</p>\r\n', 'Article1413971349_ameria-exp.png', 0, NULL, 0, 1, '2014-10-22 15:19:20'),
(152, 'user', 1214, '8000', 'Finaly we Done', '37', '<p>Finaly we Done</p>\r\n', '<p>Finaly we Done</p>\r\n', 'Article1413971620_mid_section_img_003.jpg', 400, NULL, 0, 1, '2014-10-22 15:23:44'),
(153, 'user', 1216, '45566', 'etre', '37', '<p>retrettr</p>\r\n', '<p>tretre</p>\r\n', 'Article1413978211_arrow_white.png', 0, NULL, 0, 1, '2014-10-22 17:13:36'),
(154, 'user', 1214, '6000', 'Test Today', '28', '<p>Test</p>\r\n', '<p>test</p>\r\n', 'Article1415183542_mid_section_img_003.jpg', 0, NULL, 0, 1, '2014-11-05 16:02:25'),
(155, 'user', 1214, '9633', 'Today Article', '37', '<p>asd</p>\r\n', '<p>dsfds</p>\r\n', 'Article1415183982_main_slider_01.jpg', 0, NULL, 1, 1, '2014-11-05 16:09:46'),
(156, 'user', 1214, '30000', 'This is for my dog!!', '37', '<p>sd</p>\r\n', '<p>sds</p>\r\n', 'Article1415184642_ameria-exp.png', 100, NULL, 1, 1, '2014-11-05 16:20:48');

-- --------------------------------------------------------

--
-- Table structure for table `banners`
--

CREATE TABLE IF NOT EXISTS `banners` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `category` varchar(100) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` varchar(255) NOT NULL,
  `order` int(11) NOT NULL,
  `image` varchar(255) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=74 ;

--
-- Dumping data for table `banners`
--

INSERT INTO `banners` (`id`, `category`, `title`, `content`, `order`, `image`, `date`) VALUES
(47, '1', 'Raise more money on GiveForward', 'Raise more money on GiveForward', 2, 'banner_1403526908_slider-bg-img.jpg', '0000-00-00 00:00:00'),
(72, '1', 'Crowdfunding for Musicians!', 'Crowdfunding for Musicians!', 5, 'banner_1409246714_banner-img.jpg', '0000-00-00 00:00:00'),
(73, '1', 'banner', 'banner', 3, 'banner_1409897718_banner-img.jpg', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(255) NOT NULL,
  `parent_id` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=41 ;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `category`, `parent_id`, `status`) VALUES
(36, 'Sports', 0, 1),
(37, 'Cricket', 36, 1),
(38, 'Medical PHD', 27, 1),
(39, 'Other', 0, 1),
(29, 'Pharma', 27, 1),
(28, 'Education', 0, 1),
(27, 'Medical', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `commonquestions`
--

CREATE TABLE IF NOT EXISTS `commonquestions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `question` varchar(255) NOT NULL,
  `answer` longtext NOT NULL,
  `status` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `commonquestions`
--

INSERT INTO `commonquestions` (`id`, `question`, `answer`, `status`, `date`) VALUES
(14, 'What can I raise money for?', '<div class="faqpane" style="">Most people use GoFundMe to raise money for themselves, a friend or loved one                         during life''s important moments. This includes things like <a href="http://www.gofundme.com/Medical-Illness-Healing/">medical expenses</a>,                         <a href="http://www.gofundme.com/Education-Schools-Learning/">education costs</a>, <a href="http://www.gofundme.com/Volunteer-Service/">volunteer programs</a>, <a href="http://www.gofundme.com/Sports-Teams-Clubs/">youth sports</a>, <a href="http://www.gofundme.com/Funerals-Memorials-Tributes/">funerals &amp; memorials</a>                         - even <a href="http://www.gofundme.com/Animals-Pets/">animals &amp; pets</a>.                         <br />\r\n<p><br />\r\nThat said, we''re always amazed at all the unique ways people use GoFundMe to                         raise money online. The possibilities are endless! Watch some <a href="http://www.gofundme.com/questions/#" class="video-link" data-videourl="http://www.youtube.com/embed/ffhd5VrAEeE?rel=0&amp;autoplay=1&amp;showinfo=0">Recent Success                                 Stories</a> or <a href="http://www.gofundme.com/online-fundraising">Take the Tour &gt;&gt;</a>.</p>\r\n</div>', 1, '2014-08-05 16:03:48'),
(15, 'Is it safe?', '<p>Your GoFundMe campaign features the very best in secure payment  encryption                         technology. Not only are your donors''  online payments safe, your money is stored                          securely until you''re ready to request a withdrawal via check or  electronic bank                         transfer.</p>', 1, '2014-08-05 16:14:37');

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

CREATE TABLE IF NOT EXISTS `contacts` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `website_name` varchar(120) NOT NULL,
  `email` varchar(120) NOT NULL,
  `phone1` int(10) NOT NULL,
  `phone2` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `address` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `contacts`
--

INSERT INTO `contacts` (`id`, `website_name`, `email`, `phone1`, `phone2`, `created_at`, `address`) VALUES
(1, 'company.com', 'emmanueljones@pangiadev.com', 703, 703, '2014-11-17 17:52:58', 'The Company Name Inc. 1234 Street Road,City Name, IN 567890');

-- --------------------------------------------------------

--
-- Table structure for table `countries`
--

CREATE TABLE IF NOT EXISTS `countries` (
  `idCountry` int(5) NOT NULL AUTO_INCREMENT,
  `countryCode` char(2) NOT NULL DEFAULT '',
  `countryName` varchar(45) NOT NULL DEFAULT '',
  PRIMARY KEY (`idCountry`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=251 ;

--
-- Dumping data for table `countries`
--

INSERT INTO `countries` (`idCountry`, `countryCode`, `countryName`) VALUES
(1, 'AD', 'Andorra'),
(2, 'AE', 'United Arab Emirates'),
(3, 'AF', 'Afghanistan'),
(4, 'AG', 'Antigua and Barbuda'),
(5, 'AI', 'Anguilla'),
(6, 'AL', 'Albania'),
(7, 'AM', 'Armenia'),
(8, 'AO', 'Angola'),
(9, 'AQ', 'Antarctica'),
(10, 'AR', 'Argentina'),
(11, 'AS', 'American Samoa'),
(12, 'AT', 'Austria'),
(13, 'AU', 'Australia'),
(14, 'AW', 'Aruba'),
(15, 'AX', 'Aland'),
(16, 'AZ', 'Azerbaijan'),
(17, 'BA', 'Bosnia and Herzegovina'),
(18, 'BB', 'Barbados'),
(19, 'BD', 'Bangladesh'),
(20, 'BE', 'Belgium'),
(21, 'BF', 'Burkina Faso'),
(22, 'BG', 'Bulgaria'),
(23, 'BH', 'Bahrain'),
(24, 'BI', 'Burundi'),
(25, 'BJ', 'Benin'),
(26, 'BL', 'Saint Barthelemy'),
(27, 'BM', 'Bermuda'),
(28, 'BN', 'Brunei'),
(29, 'BO', 'Bolivia'),
(30, 'BQ', 'Bonaire'),
(31, 'BR', 'Brazil'),
(32, 'BS', 'Bahamas'),
(33, 'BT', 'Bhutan'),
(34, 'BV', 'Bouvet Island'),
(35, 'BW', 'Botswana'),
(36, 'BY', 'Belarus'),
(37, 'BZ', 'Belize'),
(38, 'CA', 'Canada'),
(39, 'CC', 'Cocos [Keeling] Islands'),
(40, 'CD', 'Democratic Republic of the Congo'),
(41, 'CF', 'Central African Republic'),
(42, 'CG', 'Republic of the Congo'),
(43, 'CH', 'Switzerland'),
(44, 'CI', 'Ivory Coast'),
(45, 'CK', 'Cook Islands'),
(46, 'CL', 'Chile'),
(47, 'CM', 'Cameroon'),
(48, 'CN', 'China'),
(49, 'CO', 'Colombia'),
(50, 'CR', 'Costa Rica'),
(51, 'CU', 'Cuba'),
(52, 'CV', 'Cape Verde'),
(53, 'CW', 'Curacao'),
(54, 'CX', 'Christmas Island'),
(55, 'CY', 'Cyprus'),
(56, 'CZ', 'Czechia'),
(57, 'DE', 'Germany'),
(58, 'DJ', 'Djibouti'),
(59, 'DK', 'Denmark'),
(60, 'DM', 'Dominica'),
(61, 'DO', 'Dominican Republic'),
(62, 'DZ', 'Algeria'),
(63, 'EC', 'Ecuador'),
(64, 'EE', 'Estonia'),
(65, 'EG', 'Egypt'),
(66, 'EH', 'Western Sahara'),
(67, 'ER', 'Eritrea'),
(68, 'ES', 'Spain'),
(69, 'ET', 'Ethiopia'),
(70, 'FI', 'Finland'),
(71, 'FJ', 'Fiji'),
(72, 'FK', 'Falkland Islands'),
(73, 'FM', 'Micronesia'),
(74, 'FO', 'Faroe Islands'),
(75, 'FR', 'France'),
(76, 'GA', 'Gabon'),
(77, 'GB', 'United Kingdom'),
(78, 'GD', 'Grenada'),
(79, 'GE', 'Georgia'),
(80, 'GF', 'French Guiana'),
(81, 'GG', 'Guernsey'),
(82, 'GH', 'Ghana'),
(83, 'GI', 'Gibraltar'),
(84, 'GL', 'Greenland'),
(85, 'GM', 'Gambia'),
(86, 'GN', 'Guinea'),
(87, 'GP', 'Guadeloupe'),
(88, 'GQ', 'Equatorial Guinea'),
(89, 'GR', 'Greece'),
(90, 'GS', 'South Georgia and the South Sandwich Islands'),
(91, 'GT', 'Guatemala'),
(92, 'GU', 'Guam'),
(93, 'GW', 'Guinea-Bissau'),
(94, 'GY', 'Guyana'),
(95, 'HK', 'Hong Kong'),
(96, 'HM', 'Heard Island and McDonald Islands'),
(97, 'HN', 'Honduras'),
(98, 'HR', 'Croatia'),
(99, 'HT', 'Haiti'),
(100, 'HU', 'Hungary'),
(101, 'ID', 'Indonesia'),
(102, 'IE', 'Ireland'),
(103, 'IL', 'Israel'),
(104, 'IM', 'Isle of Man'),
(105, 'IN', 'India'),
(106, 'IO', 'British Indian Ocean Territory'),
(107, 'IQ', 'Iraq'),
(108, 'IR', 'Iran'),
(109, 'IS', 'Iceland'),
(110, 'IT', 'Italy'),
(111, 'JE', 'Jersey'),
(112, 'JM', 'Jamaica'),
(113, 'JO', 'Jordan'),
(114, 'JP', 'Japan'),
(115, 'KE', 'Kenya'),
(116, 'KG', 'Kyrgyzstan'),
(117, 'KH', 'Cambodia'),
(118, 'KI', 'Kiribati'),
(119, 'KM', 'Comoros'),
(120, 'KN', 'Saint Kitts and Nevis'),
(121, 'KP', 'North Korea'),
(122, 'KR', 'South Korea'),
(123, 'KW', 'Kuwait'),
(124, 'KY', 'Cayman Islands'),
(125, 'KZ', 'Kazakhstan'),
(126, 'LA', 'Laos'),
(127, 'LB', 'Lebanon'),
(128, 'LC', 'Saint Lucia'),
(129, 'LI', 'Liechtenstein'),
(130, 'LK', 'Sri Lanka'),
(131, 'LR', 'Liberia'),
(132, 'LS', 'Lesotho'),
(133, 'LT', 'Lithuania'),
(134, 'LU', 'Luxembourg'),
(135, 'LV', 'Latvia'),
(136, 'LY', 'Libya'),
(137, 'MA', 'Morocco'),
(138, 'MC', 'Monaco'),
(139, 'MD', 'Moldova'),
(140, 'ME', 'Montenegro'),
(141, 'MF', 'Saint Martin'),
(142, 'MG', 'Madagascar'),
(143, 'MH', 'Marshall Islands'),
(144, 'MK', 'Macedonia'),
(145, 'ML', 'Mali'),
(146, 'MM', 'Myanmar [Burma]'),
(147, 'MN', 'Mongolia'),
(148, 'MO', 'Macao'),
(149, 'MP', 'Northern Mariana Islands'),
(150, 'MQ', 'Martinique'),
(151, 'MR', 'Mauritania'),
(152, 'MS', 'Montserrat'),
(153, 'MT', 'Malta'),
(154, 'MU', 'Mauritius'),
(155, 'MV', 'Maldives'),
(156, 'MW', 'Malawi'),
(157, 'MX', 'Mexico'),
(158, 'MY', 'Malaysia'),
(159, 'MZ', 'Mozambique'),
(160, 'NA', 'Namibia'),
(161, 'NC', 'New Caledonia'),
(162, 'NE', 'Niger'),
(163, 'NF', 'Norfolk Island'),
(164, 'NG', 'Nigeria'),
(165, 'NI', 'Nicaragua'),
(166, 'NL', 'Netherlands'),
(167, 'NO', 'Norway'),
(168, 'NP', 'Nepal'),
(169, 'NR', 'Nauru'),
(170, 'NU', 'Niue'),
(171, 'NZ', 'New Zealand'),
(172, 'OM', 'Oman'),
(173, 'PA', 'Panama'),
(174, 'PE', 'Peru'),
(175, 'PF', 'French Polynesia'),
(176, 'PG', 'Papua New Guinea'),
(177, 'PH', 'Philippines'),
(178, 'PK', 'Pakistan'),
(179, 'PL', 'Poland'),
(180, 'PM', 'Saint Pierre and Miquelon'),
(181, 'PN', 'Pitcairn Islands'),
(182, 'PR', 'Puerto Rico'),
(183, 'PS', 'Palestine'),
(184, 'PT', 'Portugal'),
(185, 'PW', 'Palau'),
(186, 'PY', 'Paraguay'),
(187, 'QA', 'Qatar'),
(188, 'RE', 'Reunion'),
(189, 'RO', 'Romania'),
(190, 'RS', 'Serbia'),
(191, 'RU', 'Russia'),
(192, 'RW', 'Rwanda'),
(193, 'SA', 'Saudi Arabia'),
(194, 'SB', 'Solomon Islands'),
(195, 'SC', 'Seychelles'),
(196, 'SD', 'Sudan'),
(197, 'SE', 'Sweden'),
(198, 'SG', 'Singapore'),
(199, 'SH', 'Saint Helena'),
(200, 'SI', 'Slovenia'),
(201, 'SJ', 'Svalbard and Jan Mayen'),
(202, 'SK', 'Slovakia'),
(203, 'SL', 'Sierra Leone'),
(204, 'SM', 'San Marino'),
(205, 'SN', 'Senegal'),
(206, 'SO', 'Somalia'),
(207, 'SR', 'Suriname'),
(208, 'SS', 'South Sudan'),
(209, 'ST', 'São Tomé and Príncipe'),
(210, 'SV', 'El Salvador'),
(211, 'SX', 'Sint Maarten'),
(212, 'SY', 'Syria'),
(213, 'SZ', 'Swaziland'),
(214, 'TC', 'Turks and Caicos Islands'),
(215, 'TD', 'Chad'),
(216, 'TF', 'French Southern Territories'),
(217, 'TG', 'Togo'),
(218, 'TH', 'Thailand'),
(219, 'TJ', 'Tajikistan'),
(220, 'TK', 'Tokelau'),
(221, 'TL', 'East Timor'),
(222, 'TM', 'Turkmenistan'),
(223, 'TN', 'Tunisia'),
(224, 'TO', 'Tonga'),
(225, 'TR', 'Turkey'),
(226, 'TT', 'Trinidad and Tobago'),
(227, 'TV', 'Tuvalu'),
(228, 'TW', 'Taiwan'),
(229, 'TZ', 'Tanzania'),
(230, 'UA', 'Ukraine'),
(231, 'UG', 'Uganda'),
(232, 'UM', 'U.S. Minor Outlying Islands'),
(233, 'US', 'United States'),
(234, 'UY', 'Uruguay'),
(235, 'UZ', 'Uzbekistan'),
(236, 'VA', 'Vatican City'),
(237, 'VC', 'Saint Vincent and the Grenadines'),
(238, 'VE', 'Venezuela'),
(239, 'VG', 'British Virgin Islands'),
(240, 'VI', 'U.S. Virgin Islands'),
(241, 'VN', 'Vietnam'),
(242, 'VU', 'Vanuatu'),
(243, 'WF', 'Wallis and Futuna'),
(244, 'WS', 'Samoa'),
(245, 'XK', 'Kosovo'),
(246, 'YE', 'Yemen'),
(247, 'YT', 'Mayotte'),
(248, 'ZA', 'South Africa'),
(249, 'ZM', 'Zambia'),
(250, 'ZW', 'Zimbabwe');

-- --------------------------------------------------------

--
-- Table structure for table `donations`
--

CREATE TABLE IF NOT EXISTS `donations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `article_id` int(11) NOT NULL,
  `amount` int(255) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `hideinfo` tinyint(4) NOT NULL DEFAULT '0',
  `email` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `zip` bigint(20) NOT NULL,
  `image` varchar(255) NOT NULL,
  `comment` text NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=143 ;

--
-- Dumping data for table `donations`
--

INSERT INTO `donations` (`id`, `article_id`, `amount`, `firstname`, `lastname`, `hideinfo`, `email`, `country`, `zip`, `image`, `comment`, `date`) VALUES
(7, 26, 500, 'ashwani', '', 0, 'ashwanik.softprodigy@gmail.com', 'india', 12345, 'user_1404393534_baby-boy-wearing-hat.jpg', 'your comment here', '2014-07-03 18:48:54'),
(8, 26, 500, 'ashwani', 'kaushal', 0, 'ashwanik.softprodigy@gmail.com', 'india', 123445, 'user_1404393755_baby-boy-wearing-hat.jpg', 'your comment here', '2014-07-03 18:52:35'),
(9, 26, 4545, 'ashwani', 'kaushal', 0, 'ashwanik.softprodigy@gmail.com', 'india', 123445, 'user_1404393896_baby-boy-wearing-hat.jpg', 'your comment here', '2014-07-03 18:54:56'),
(16, 49, 300, 'ashwani', 'kaushal', 0, 'ajay@gmail.com', 'india', 12345, '', '', '2014-07-04 22:10:55'),
(17, 45, 300, 'ashwani', 'kaushal', 0, 'ashwanik.softprodigy@gmail.com', 'india', 12345, '', '', '2014-07-07 14:35:28'),
(18, 45, 300, 'ashwani', 'kaushal', 0, 'ashwanik.softprodigy@gmail.com', 'india', 12345, '', '', '2014-07-07 14:36:43'),
(19, 45, 300, 'ashwani', 'kaushal', 0, 'ashwanik.softprodigy@gmail.com', 'india', 12345, '', '', '2014-07-07 14:37:35'),
(20, 45, 300, 'ashwani', 'kaushal', 0, 'ashwanik.softprodigy@gmail.com', 'india', 12345, '', '', '2014-07-07 14:37:58'),
(21, 45, 300, 'rajat', 'sharma', 0, 'ashwanik.softprodigy@gmail.com', 'india', 12345, '', '', '2014-07-07 15:00:23'),
(22, 45, 300, 'rajat', 'sharma', 0, 'ashwanik.softprodigy@gmail.com', 'india', 12345, '', '', '2014-07-07 15:02:54'),
(23, 45, 300, 'rajat', 'sharma', 0, 'ashwanik.softprodigy@gmail.com', 'india', 12345, '', '', '2014-07-07 15:05:21'),
(24, 45, 300, 'rajat', 'sharma', 0, 'ashwanik.softprodigy@gmail.com', 'india', 12345, '', '', '2014-07-07 15:11:41'),
(25, 45, 300, 'rajat', 'sharma', 0, 'ashwanik.softprodigy@gmail.com', 'india', 12345, '', '', '2014-07-07 15:12:12'),
(26, 45, 300, 'rajat', 'sharma', 0, 'ashwanik.softprodigy@gmail.com', 'india', 12345, '', '', '2014-07-07 15:12:53'),
(27, 45, 300, 'rajat', 'sharma', 0, 'ashwanik.softprodigy@gmail.com', 'india', 12345, '', '', '2014-07-07 15:13:55'),
(28, 45, 300, 'rajat', 'sharma', 0, 'ashwanik.softprodigy@gmail.com', 'india', 12345, '', '', '2014-07-07 15:14:17'),
(29, 45, 300, 'rajat', 'sharma', 0, 'ashwanik.softprodigy@gmail.com', 'india', 12345, '', '', '2014-07-07 15:15:01'),
(30, 45, 300, 'deepak', 'kaushal', 0, 'ashwanik.softprodigy@gmail.com', 'india', 12345, '', '', '2014-07-07 16:12:02'),
(31, 45, 4003, 'shiv', 'sharma', 0, 'ashwani@gmail.com', 'india', 12345, '', '', '2014-07-06 16:26:36'),
(32, 49, 2300, 'raman', 'singh', 0, 'raman@gmail.com', 'india', 12345, '', '', '2014-07-07 18:38:56'),
(33, 49, 300, 'ajay', 'ajay', 0, 'ajay@gmail.com', 'india', 12345, 'user_1404739187_baby-boy-wearing-hat.jpg', '', '2014-07-07 18:49:47'),
(34, 49, 300, 'shiv', 'kaushal', 0, 'ashwani@gmail.com', 'india', 12345, '', '', '2014-07-07 18:57:57'),
(35, 49, 300, 'ashwani', 'kaushal', 0, 'ashwanik.softprodigy@gmail.com', 'india', 12345, '', '', '2014-07-08 12:27:54'),
(36, 49, 300, 'ashwaniiiii', 'kaushalllll', 0, 'ashwanik.softprodigy@gmail.com', 'india', 12345, 'user_1404802713_baby-boy-wearing-hat.jpg', '', '2014-07-08 12:28:33'),
(37, 51, 400, 'ashwani', 'kaushal', 0, 'ashwabi@gmail.com', 'india', 12345, '', '', '2014-07-08 19:39:18'),
(38, 49, 1200, 'Neeraj', 'Sarathe', 0, 'neerajsoftprodigy1@gmail.com', 'India', 124312, '', 'Hey,,Go ahead guys', '2014-07-09 16:34:59'),
(39, 53, 20, 'Kanchan', 'Grover', 0, 'kanchan.softprodigy@gmail.com', 'India', 231234, 'user_1404908844_imagescv.jpg', 'Get well soon. Tc', '2014-07-09 17:57:24'),
(40, 56, 500, 'ashwani', 'kaushal', 0, 'ashwanik.softprodigy@gmail.com', 'india', 12345, 'user_1404970665_watchmen_smiley-HD.jpg', 'comment......', '2014-07-10 11:07:45'),
(41, 49, 500, 'deepak', 'sharma', 0, 'deepak@gmail.com', 'india', 12345, '', '', '2014-07-10 11:38:05'),
(42, 51, 400, 'ashwani', 'kausjhall', 0, 'ashwanik.softprodigy@gmail.com', 'india', 12345, '', '', '2014-07-10 15:35:26'),
(43, 72, 300, 'ashwani', 'kaushal', 0, 'ashwanik.softprodigy@gmail.com', 'india', 12345, 'user_1405079068_watchmen_smiley-HD.jpg', '', '2014-07-11 17:14:29'),
(44, 77, 300, 'ashwani', 'kaushal', 0, 'ashwanik.softprodigy@gmail.com', 'india', 12345, 'user_1405090381_watchmen_smiley-HD.jpg', 'comment......', '2014-07-11 20:23:02'),
(45, 49, 25, 'Jayant', 'Sharma', 0, 'jayant.softprodigy@gmail.com', 'India', 160055, '', ' Please Donate more', '2014-07-11 20:24:57'),
(46, 49, 3333, 'Jayant', 'Sharma', 0, 'jayant.softprodigy@gmail.com', 'india', 160055, '', 'test ', '2014-07-14 11:58:31'),
(47, 96, 10, 'Aman', 'Verma', 0, 'jayant321sharma@hotmail.com', 'India', 654123, 'user_1405687852_as.jpg', 'Stay Strong', '2014-07-18 18:20:52'),
(48, 106, 400, 'ashwanii', 'kaushal', 1, 'ashwanik.softprodigy@gmail.com', 'india', 200200, '', 'get well soon', '2014-07-21 20:50:51'),
(49, 107, 500, 'ashwanii', 'kaushal', 1, 'ashwanik.softprodigy@gmail.com', 'india', 200200, '', 'hope for well', '2014-07-23 09:44:36'),
(50, 94, 25, 'Manav', 'Chopra', 1, 'manav.softprodigy@gmail.com', 'India', 150012, '', 'Get Well Soon, Our prayers are with you.  Get Well Soon, Our prayers are with you. Get Well Soon, Our prayers are with you. Get Well Soon, Our prayers are with you. Get Well Soon, Our prayers are with you. Get Well Soon, Our prayers are with you. Get Well Soon, Our prayers are with you. Get Well Soon, Our prayers are with you. Get Well Soon, Our prayers are with you. Get Well Soon, Our prayers are with you. Get Well Soon, Our prayers are with you. Get Well Soon, Our prayers are with you. ', '2014-07-23 12:53:36'),
(51, 94, 30, 'Banita', 'verma', 1, 'banita.softprodigy@gmail.com', 'India', 173025, '', 'Get Well Soon, Our prayers are with you. Get Well Soon, Our prayers are with you. Get Well Soon, Our prayers are with you. Get Well Soon, Our prayers are with you. Get Well Soon, Our prayers are with you. Get Well Soon, Our prayers are with you. Get Well Soon, Our prayers are with you. Get Well Soon, Our prayers are with you. Get Well Soon, Our prayers are with you. Get Well Soon, Our prayers are with you. Get Well Soon, Our prayers are with you. ', '2014-07-23 12:55:44'),
(52, 94, 12, 'Jayant', 'Sharma', 0, 'jayant123sharma@hotmail.com', 'India', 160055, '', 'test', '2014-07-23 13:00:32'),
(53, 49, 30, 'Sandy', 'Singh', 0, 'sandy.singh@gmail.com', 'India', 132123, '', 'Best Wishes', '2014-07-23 14:44:32'),
(54, 49, 25, 'Kanchan', 'Sharma', 0, 'kanchan.softprodigy@gmail.com', 'India', 765432, '', 'Be well', '2014-07-23 14:45:32'),
(55, 49, 44, 'dsf', 'dsf', 1, 'sdf@gfdg.com', 'India', 12345, '', 'fdgfdg', '2014-07-23 14:46:11'),
(56, 49, 1, 'dsaf', 'dfsd', 0, 'jayant.softprodigy@gmail.com', 'sdfd', 212121, '', 'sdfsdf', '2014-07-23 14:49:32'),
(57, 96, 3000, 'Gauran', 'Saini', 0, 'gauravsoftprodigy1@gmail.com', 'India', 135001, 'user_1406107364_as.jpg', 'Get well..Pray for you', '2014-07-23 14:52:44'),
(58, 106, 400, 'ashwani', 'kaushal', 0, 'ashwani@gmail.com', 'india', 12345, '', '', '2014-07-23 16:12:33'),
(67, 110, 300, 'Gaurav', 'Saini', 1, 'gauravsoftprodigy1@gmail.com', 'India', 150012, '', 'All the best', '2014-07-25 18:46:14'),
(68, 110, 400, 'Kanchan', 'Grover', 0, 'kanchan.softprodigy@gmail.com', 'India', 12345, 'user_1406294603_Books_1400185c.jpg', 'Wish you Good Luck', '2014-07-25 18:53:23'),
(69, 112, 400, 'punnet', 'kaushal', 1, 'punitkaushal790@gmail.com', 'india', 12345, '', 'hide my info', '2014-07-30 13:38:55'),
(70, 112, 400, 'ashwani', 'kaushal', 0, 'ashwani@gmail.com', 'india', 12345, '', '', '2014-07-30 15:51:47'),
(71, 94, 40, 'Kanchan', 'Grover', 1, 'kanchan.softprodigy@gmail.com', 'India', 143212, '', '', '2014-07-31 20:07:01'),
(72, 94, 60, 'Kanchan', 'Grover', 1, 'kanchan.softprodigy@gmail.com', 'India', 160055, 'user_1406817716_as.jpg', 'Good work ...', '2014-07-31 20:11:56'),
(73, 118, 400, 'ashwanii', 'kaushal', 1, 'ashwanik.softprodigy@gmail.com', 'india', 200200, '', '', '2014-08-01 11:33:12'),
(74, 123, 300, 'ashwani', 'kaushal1', 0, 'ash@gmail.com', '105', 12345, '', 'final', '2014-08-01 21:11:29'),
(75, 125, 100, 'ashwani', 'kaushal', 8, 'ashwanik.softprodigy@gmail.com', 'india', 140124, '', '', '2014-08-25 21:03:45'),
(76, 125, 100, 'ashwani', 'kaushal', 8, 'ashwanik.softprodigy@gmail.com', 'india', 140124, '', '', '2014-08-25 21:06:41'),
(77, 125, 100, 'ashwani', 'kaushal', 8, 'ashwanik.softprodigy@gmail.com', 'india', 140124, '', '', '2014-08-25 21:08:00'),
(78, 125, 100, 'ashwani', 'kaushal', 0, 'ashwanik.softprodigy@gmail.com', 'india', 140124, '', '', '2014-08-25 21:15:50'),
(79, 125, 100, 'ashwani', 'kaushal', 0, 'ashwanik.softprodigy@gmail.com', 'india', 140124, '', '', '2014-08-25 21:18:59'),
(80, 125, 100, 'ashwani', 'kaushal', 0, 'ashwanik.softprodigy@gmail.com', 'india', 140124, '', '', '2014-08-25 21:19:46'),
(81, 125, 100, 'ashwani', 'kaushal', 0, 'ashwanik.softprodigy@gmail.com', 'india', 140124, '', '', '2014-08-25 21:20:32'),
(82, 125, 100, 'ashwani', 'kaushal', 0, 'ashwanik.softprodigy@gmail.com', 'india', 140124, '', '', '2014-08-25 21:20:33'),
(83, 125, 100, 'ashwani', 'kaushal', 0, 'ashwanik.softprodigy@gmail.com', 'india', 140124, '', '', '2014-08-25 21:20:34'),
(84, 125, 100, 'ashwani', 'kaushal', 0, 'ashwanik.softprodigy@gmail.com', 'india', 140124, '', '', '2014-08-25 21:20:34'),
(85, 125, 100, 'ashwani', 'kaushal', 0, 'ashwanik.softprodigy@gmail.com', 'india', 140124, '', '', '2014-08-25 21:20:34'),
(86, 125, 100, 'ashwani', 'kaushal', 0, 'ashwanik.softprodigy@gmail.com', 'india', 140124, '', '', '2014-08-25 21:20:35'),
(87, 125, 100, 'ashwani', 'kaushal', 0, 'ashwanik.softprodigy@gmail.com', 'india', 140124, '', '', '2014-08-25 21:20:35'),
(88, 125, 100, 'ashwani', 'kaushal', 0, 'ashwanik.softprodigy@gmail.com', 'india', 140124, '', '', '2014-08-25 21:20:35'),
(89, 125, 100, 'ashwani', 'kaushal', 0, 'ashwanik.softprodigy@gmail.com', 'india', 140124, '', '', '2014-08-25 21:20:35'),
(90, 125, 100, 'ashwani', 'kaushal', 0, 'ashwanik.softprodigy@gmail.com', 'india', 140124, '', '', '2014-08-25 21:20:36'),
(91, 125, 100, 'ashwani', 'kaushal', 0, 'ashwanik.softprodigy@gmail.com', 'india', 140124, '', '', '2014-08-25 21:20:36'),
(92, 125, 100, 'ashwani', 'kaushal', 0, 'ashwanik.softprodigy@gmail.com', 'india', 140124, '', '', '2014-08-25 21:20:57'),
(93, 125, 100, 'ashwani', 'kaushal', 0, 'ashwanik.softprodigy@gmail.com', 'india', 140124, '', '', '2014-08-25 21:21:35'),
(94, 125, 100, 'ashwani', 'kaushal', 0, 'ashwanik.softprodigy@gmail.com', 'india', 140124, '', '', '2014-08-25 21:21:44'),
(95, 125, 100, 'ashwani', 'kaushal', 0, 'ashwanik.softprodigy@gmail.com', 'india', 140124, '', '', '2014-08-25 21:21:44'),
(96, 125, 100, 'ashwani', 'kaushal', 0, 'ashwanik.softprodigy@gmail.com', 'india', 140124, '', '', '2014-08-25 21:21:45'),
(97, 125, 100, 'ashwani', 'kaushal', 0, 'ashwanik.softprodigy@gmail.com', 'india', 140124, '', '', '2014-08-25 21:21:45'),
(98, 125, 100, 'ashwani', 'kaushal', 0, 'ashwanik.softprodigy@gmail.com', 'india', 140124, '', '', '2014-08-25 21:21:46'),
(99, 125, 100, 'ashwani', 'kaushal', 0, 'ashwanik.softprodigy@gmail.com', 'india', 140124, '', '', '2014-08-25 21:21:46'),
(100, 125, 100, 'ashwani', 'kaushal', 0, 'ashwanik.softprodigy@gmail.com', 'india', 140124, '', '', '2014-08-25 21:21:47'),
(101, 125, 100, 'ashwani', 'kaushal', 0, 'ashwanik.softprodigy@gmail.com', 'india', 140124, '', '', '2014-08-25 21:21:48'),
(102, 125, 100, 'ashwani', 'kaushal', 0, 'ashwanik.softprodigy@gmail.com', 'india', 140124, '', '', '2014-08-25 21:21:48'),
(103, 125, 100, 'ashwani', 'kaushal', 0, 'ashwanik.softprodigy@gmail.com', 'india', 140124, '', '', '2014-08-25 21:21:48'),
(104, 125, 100, 'ashwani', 'kaushal', 0, 'ashwanik.softprodigy@gmail.com', 'india', 140124, '', '', '2014-08-25 21:21:48'),
(105, 125, 100, 'ashwani', 'kaushal', 0, 'ashwanik.softprodigy@gmail.com', 'india', 140124, '', '', '2014-08-25 21:21:49'),
(106, 125, 100, 'ashwani', 'kaushal', 0, 'ashwanik.softprodigy@gmail.com', 'india', 140124, '', '', '2014-08-25 21:21:49'),
(107, 125, 100, 'ashwani', 'kaushal', 0, 'ashwanik.softprodigy@gmail.com', 'india', 140124, '', '', '2014-08-25 21:21:49'),
(108, 125, 100, 'ashwani', 'kaushal', 0, 'ashwanik.softprodigy@gmail.com', 'india', 140124, '', '', '2014-08-25 21:21:49'),
(109, 125, 100, 'ashwani', 'kaushal', 0, 'ashwanik.softprodigy@gmail.com', 'india', 140124, '', '', '2014-08-25 21:21:50'),
(110, 125, 100, 'ashwani', 'kaushal', 0, 'ashwanik.softprodigy@gmail.com', 'india', 140124, '', '', '2014-08-25 21:21:50'),
(111, 125, 100, 'ashwani', 'kaushal', 0, 'ashwanik.softprodigy@gmail.com', 'india', 140124, '', '', '2014-08-25 21:21:50'),
(112, 125, 100, 'ashwani', 'kaushal', 0, 'ashwanik.softprodigy@gmail.com', 'india', 140124, '', '', '2014-08-25 21:22:03'),
(113, 125, 100, 'ashwani', 'kaushal', 0, 'ashwanik.softprodigy@gmail.com', 'india', 140124, '', '', '2014-08-25 21:23:04'),
(114, 125, 100, 'ashwani', 'kaushal', 0, 'ashwanik.softprodigy@gmail.com', 'india', 140124, '', '', '2014-08-25 21:23:21'),
(115, 125, 100, 'ashwani', 'kaushal', 0, 'ashwanik.softprodigy@gmail.com', 'india', 140124, '', '', '2014-08-25 21:27:19'),
(116, 125, 100, 'ashwani', 'kaushal', 0, 'ashwanik.softprodigy@gmail.com', 'india', 140124, '', '', '2014-08-25 21:27:22'),
(117, 123, 100, 'ashwani', 'kaushal2', 0, 'ashwanik.softprodigy@gmail.com', 'india', 140124, '', '', '2014-08-26 19:54:38'),
(118, 123, 100, 'ashwani', 'kaushal3', 0, 'ashwanik.softprodigy@gmail.com', 'india', 140124, '', '', '2014-08-26 20:01:55'),
(119, 123, 100, 'ashwani', 'kaushal4', 0, 'ashwanik.softprodigy@gmail.com', 'india', 140124, '', '', '2014-08-26 20:02:17'),
(120, 123, 100, 'ashwani', 'kaushal5', 0, 'ashwanik.softprodigy@gmail.com', 'india', 140124, '', '', '2014-08-26 20:05:55'),
(121, 123, 100, 'ashwani', 'kaushal6', 0, 'ashwanik.softprodigy@gmail.com', 'india', 140124, '', '', '2014-08-26 20:07:56'),
(122, 127, 100, 'Raj', 'Dhiman', 0, 'raj.softprodigy@gmail.com', '105', 160055, '', 'Comment', '2014-09-05 18:22:47'),
(123, 140, 100, 'Jayant', 'Sharma', 0, 'jayant123sharma@hotmail.com', '233', 160055, 'user_1410420755_image002-732513.png', 'Hey guys, Plz donate.', '2014-09-11 13:09:09'),
(124, 140, 400, 'Kanchan', 'Grover', 0, 'kanchan.softprodigy@gmail.com', '233', 21223, 'user_1410421659_d.jpg', 'megadeth..', '2014-09-11 13:20:46'),
(125, 140, 100, 'ashwani', 'kaushal', 1, 'ashwanik.softprodigy@gmail.com', '105', 12345, '', 'comment...', '2014-09-15 19:16:07'),
(126, 140, 100, 'ashwani', 'kaushal', 0, 'ashwanik.softprodigy@gmail.com', '105', 12345, '', '..', '2014-09-15 19:45:58'),
(127, 140, 100, 'ashwani', 'kaushal', 0, 'ashwanik.softprodigy@gmail.com', '104', 12345, '', 'gdkjhs', '2014-09-15 19:51:47'),
(128, 140, 100, 'ashwani', 'kaushal', 0, 'ashwanik.softprodigy@gmail.com', '105', 12345, '', 'gdf', '2014-09-15 20:21:09'),
(129, 140, 100, 'ashwani', 'kaushal', 1, 'ashwanik.softprodigy@gmail.com', '105', 12345, '', 'test donation..', '2014-09-15 20:27:05'),
(130, 140, 101, 'ashwani', 'kaushal', 1, 'ashwanik.softprodigy@gmail.com', '105', 12345, '', 'jdskjas', '2014-09-16 13:17:24'),
(131, 140, 5000, 'Gaurav', 'Saini', 0, 'gauravsoftprodigy1@gmail.com', '105', 160055, '', 'Money for the Good Cause', '2014-09-22 14:38:14'),
(132, 140, 5000, 'Gaurav', 'Saini', 1, 'gauravsoftprodigy1@gmail.com', '105', 160055, '', 'Testing', '2014-09-22 14:59:02'),
(133, 141, 3000, 'Kanchan', 'Grover', 0, 'kanchan.softprodigy@gmail.com', '105', 160055, '', 'dfghdfgdfg', '2014-09-22 19:10:41'),
(134, 140, 100, 'ashwani', 'kaushal', 0, 'ash@gmail.com', '101', 12345, '', '...', '2014-09-29 15:35:28'),
(135, 140, 100, 'ashwani', 'kaushal', 0, 'ashwanik.softprodigy@gmail.com', '105', 140124, '', 'hope for well!', '2014-10-15 14:31:13'),
(136, 140, 100, 'rajj', 'dhiman', 0, 'raj_dhiman@softprodigy.com', '105', 12345, '', 'sdf', '2014-10-18 13:28:38'),
(137, 140, 100, 'arjun', 'arjun', 1, 'arjun@gmail.com', '105', 140124, '', 'hj', '2014-10-18 14:23:11'),
(138, 152, 100, 'anit', 'amit', 0, 'pardeepbuz@gmail.com', '105', 12345, '', 'Done!', '2014-10-22 15:32:05'),
(139, 152, 100, 'ashwani', 'kaushal', 0, 'ashwanik@gmail.com', '105', 12345, '', 'Done!', '2014-10-22 15:43:13'),
(140, 152, 100, 'sadas', 'sdasd', 0, 'sdsad@gmail.com', '105', 12345, '', 'done!', '2014-10-22 15:45:41'),
(141, 152, 100, 'sdefsf', 'dsfdsf', 0, 'dsfds@gmail.com', '18', 12345, '', 'desf', '2014-10-22 15:48:29'),
(142, 156, 100, 'anit', 'amit', 0, 'sharma.akshat3184@yahoo.com', '2', 12345, '', '', '2014-11-05 16:41:48');

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE IF NOT EXISTS `events` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `event_name` varchar(120) NOT NULL,
  `event_type` enum('rsvp','paid','noindicate') NOT NULL,
  `event_cost` float NOT NULL,
  `event_capacity` int(11) NOT NULL,
  `event_date` date NOT NULL,
  `event_image` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `event_description` longtext NOT NULL,
  `event_title` varchar(150) NOT NULL,
  `event_address` varchar(120) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`id`, `event_name`, `event_type`, `event_cost`, `event_capacity`, `event_date`, `event_image`, `created_at`, `updated_at`, `event_description`, `event_title`, `event_address`) VALUES
(1, '', '', 0, 0, '2014-01-01', 'undefined', '2014-11-17 18:19:01', '0000-00-00 00:00:00', '<p><strong>Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry''s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.<br></p><p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry''s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>', 'Event 1 Header ', ''),
(2, '', '', 1, 2, '2014-01-01', 'about01.jpg', '2014-11-17 18:19:30', '0000-00-00 00:00:00', '<p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry''s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.<br></p><p><br></p><p><br></p><p><br></p>', '2uis autem vel eum iure', '3 Street Road,City Name IN 567890.'),
(3, '', '', 151, 161, '2009-06-06', 'event_01.jpg', '2014-11-17 18:20:35', '0000-00-00 00:00:00', '<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry''s Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry''s standard dummy text ever since the 1500s, when an unknown printer took a galley of typ Event 3 done</p><p><br></p><p><br></p><p><br></p>', 'Neque porr1o quisquam est', '1Neque porro quisquam est111');

-- --------------------------------------------------------

--
-- Table structure for table `fbaccesstokens`
--

CREATE TABLE IF NOT EXISTS `fbaccesstokens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `fbid` varchar(50) NOT NULL,
  `accesstoken` varchar(500) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=24 ;

--
-- Dumping data for table `fbaccesstokens`
--

INSERT INTO `fbaccesstokens` (`id`, `uid`, `fbid`, `accesstoken`, `date`) VALUES
(23, 14, '100002566933933', 'CAADbZCfiEzO8BALCtnsNKqDQJt33lSy3c6HkFeuwOmWrGN0AEeqY9ZAkbRU1ezUdhB7HZAz8gAihPrtCm0hl4Szj8YcmzCpdHCsMKz9oEF2YcAQR5ZAFJMZAZBfba4eUqxWxmLfaoxZAPG3Bj2IZCmTqXDpppRzr6hfSMhZB4c8Rtcpo49CBkqzUSUIRNrvOqixIZD', '2014-05-27 12:44:58');

-- --------------------------------------------------------

--
-- Table structure for table `friends`
--

CREATE TABLE IF NOT EXISTS `friends` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `sid` int(100) NOT NULL,
  `rid` int(100) NOT NULL,
  `type` varchar(20) NOT NULL,
  `status` int(100) NOT NULL,
  `socialNetwork` int(10) NOT NULL DEFAULT '4',
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=221 ;

--
-- Dumping data for table `friends`
--

INSERT INTO `friends` (`id`, `sid`, `rid`, `type`, `status`, `socialNetwork`, `date`) VALUES
(219, 14, 1124, 'friend', 0, 4, '2014-05-29 18:47:38'),
(220, 14, 15, 'friend', 0, 4, '2014-05-29 19:46:19'),
(217, 14, 1214, 'family', 2, 4, '2014-05-29 18:35:22'),
(215, 14, 56, 'friend', 1, 4, '2014-05-29 18:32:42');

-- --------------------------------------------------------

--
-- Table structure for table `helps`
--

CREATE TABLE IF NOT EXISTS `helps` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `qus_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `message` longtext NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=30 ;

--
-- Dumping data for table `helps`
--

INSERT INTO `helps` (`id`, `qus_id`, `name`, `email`, `subject`, `message`, `date`) VALUES
(9, 57, 'ashwani', 'ash@gmail.com', 'Need help', '<p>gfhftgh</p><p>hgfhgfh</p><p>hgfgfh</p>', '0000-00-00 00:00:00'),
(10, 55, 'ashwani', 'ash@gmail.com', 'Need help', '<p>sdsads</p>', '2014-08-06 14:14:54'),
(11, 60, 'sadas', 'ash@gmail.com', 'Need help', '<p>sadasd</p>', '2014-08-06 14:15:13'),
(12, 58, 'sadasd', 'ash@gmail.com', 'asdasd', '<p>dasdd</p>', '2014-08-06 14:15:45'),
(13, 61, 'ashwani', 'ash@gmail.com', 'Need help', '<p>saA</p>', '2014-08-06 14:30:14'),
(14, 61, 'ashwani', 'ash@gmail.com', 'Need help', '<p>saA</p>', '2014-08-06 14:36:48'),
(15, 55, 'ashwani', 'ash@gmail.com', 'Need help', '<p>dasdas</p>', '2014-08-07 12:18:47'),
(16, 55, 'ashwani', 'ash@gmail.com', 'Need help', '<p>dasdas</p>', '2014-08-07 12:34:13'),
(17, 55, 'ashwani', 'ash@gmail.com', 'Need help', '<p>dasdas</p>', '2014-08-07 12:34:48'),
(18, 55, 'ashwani', 'ash@gmail.com', 'Need help', '<p>dasdas</p>', '2014-08-07 12:36:36'),
(19, 55, 'ashwani', 'ash@gmail.com', 'Need help', '<p>dasdas</p>', '2014-08-07 12:42:16'),
(20, 55, 'ashwani', 'ash@gmail.com', 'Need help', '<p>dasdas</p>', '2014-08-07 12:42:27'),
(21, 55, 'ashwani', 'ash@gmail.com', 'Need help', '<p>dasdas</p>', '2014-08-07 12:42:55'),
(22, 55, 'ashwani', 'punitkaushal790@gmail.com', 'Need help', '<p>dasdas</p>', '2014-08-07 12:43:24'),
(23, 55, 'ashwani', 'punitkaushal790@gmail.com', 'Need help', '<p>dasdas</p>', '2014-08-07 12:48:26'),
(24, 61, 'ashwani', 'punitkaushal790@gmail.com', 'i need help regarding this', '<p>hii</p><p>i need help regarding donation?</p><p>i9 give some donation but not got confirmation message?</p>', '2014-08-07 12:52:38'),
(25, 61, 'ashwani', 'punitkaushal790@gmail.com', 'i need help regarding this', '<p>hii</p><p>i need help regarding donation?</p><p>i9 give some donation but not got confirmation message?</p>', '2014-08-07 12:53:57'),
(26, 61, 'ashwani', 'punitkaushal790@gmail.com', 'i need help regarding this', '<p>hii</p><p>i need help regarding donation?</p><p>i9 give some donation but not got confirmation message?</p>', '2014-08-07 12:54:32'),
(27, 61, 'ashwani', 'punitkaushal790@gmail.com', 'i need help regarding this', '<p>hii</p><p>i need help regarding donation?</p><p>i9 give some donation but not got confirmation message?</p>', '2014-08-07 12:56:12'),
(28, 55, 'fdgf', 'fgfdg@gmail.com', 'fgf', '<p>fgfg</p>', '2014-10-18 12:39:04'),
(29, 55, 'fdgf', 'fgfdg@gmail.com', 'fgf', '<p>fgfg</p>', '2014-10-18 12:42:15');

-- --------------------------------------------------------

--
-- Table structure for table `members`
--

CREATE TABLE IF NOT EXISTS `members` (
  `id` int(10) NOT NULL,
  `description` longtext NOT NULL,
  `name` varchar(125) NOT NULL,
  `rating` float NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `image` varchar(125) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `members`
--

INSERT INTO `members` (`id`, `description`, `name`, `rating`, `created_at`, `image`) VALUES
(1, '<p><strong>lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry''s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\n\n<p>Ipsum</p>\n\n<p>', 'LIPSUM LIPSUM', 0, '2014-11-17 18:22:52', 'animal.jpg'),
(2, '<p><strong>lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry''s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. Eveve 2 4</p>\n', 'LIPSUM', 0, '2014-11-17 18:23:08', 'event_01.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `metatags`
--

CREATE TABLE IF NOT EXISTS `metatags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page_title` varchar(255) NOT NULL,
  `meta_keyword` text NOT NULL,
  `meta_description` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `metatags`
--

INSERT INTO `metatags` (`id`, `page_title`, `meta_keyword`, `meta_description`) VALUES
(1, 'profile', 'search profile', 'it search the users profile'),
(2, 'About_us', 'About_us', 'About_us'),
(3, 'Privacy', 'Privacy ', 'Privacy'),
(4, 'Term & conditions', 'Term & conditions', 'Term & conditions');

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE IF NOT EXISTS `questions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `question` varchar(255) NOT NULL,
  `parent_id` int(11) NOT NULL,
  `answer` longtext NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=66 ;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`id`, `title`, `question`, `parent_id`, `answer`, `status`, `time`) VALUES
(55, 'Sports', 'How does it work?', 0, '<div id="collapseOne" class="panel-collapse collapse in">\r\n<div class="panel-body">\r\n<p>Lorem Ipsum is simply dummy  text of the printing and typesetting industry. Lorem Ipsum has been the  industry''s standard dummy text ever since the 1500s, when an unknown  printer took a galley of type and scrambled it to make a t</p>\r\n<p>Watch <span class="clr-blue"> <a>How it Works or Take the Tour &gt;&gt; </a></span></p>\r\n<p>Lorem Ipsum is simply dummy  text of the printing and typesetting industry. Lorem Ipsum has been the  industry''s standard dummy text ever since the 1500s, when an unknown  printer took a galley of type and scrambled it to make a t</p>\r\n<p><span class="clr-blue"><a>Start raising money now &gt;&gt;</a></span></p>\r\n</div>\r\n</div>', 0, '2014-08-04 20:41:42'),
(58, 'Medical', 'How does it work?', 0, '<div id="collapseOne" class="panel-collapse collapse in">\r\n<div class="panel-body">\r\n<p>Lorem Ipsum is simply dummy  text of the printing and typesetting industry. Lorem Ipsum has been the  industry''s standard dummy text ever since the 1500s, when an unknown  printer took a galley of type and scrambled it to make a t</p>\r\n<p>Watch <span class="clr-blue"> <a>How it Works or Take the Tour &gt;&gt; </a></span></p>\r\n<p>Lorem Ipsum is simply dummy  text of the printing and typesetting industry. Lorem Ipsum has been the  industry''s standard dummy text ever since the 1500s, when an unknown  printer took a galley of type and scrambled it to make a t</p>\r\n<p><span class="clr-blue"><a>Start raising money now &gt;&gt;</a></span></p>\r\n</div>\r\n</div>', 1, '2014-08-04 20:42:43'),
(59, 'Medical', 'How does it work?', 58, '<div class="panel-collapse collapse in" id="collapseOne">\r\n<div class="panel-body">\r\n<p>Lorem Ipsum is simply dummy  text of the printing and typesetting industry. Lorem Ipsum has been the  industry''s standard dummy text ever since the 1500s, when an unknown  printer took a galley of type and scrambled it to make a t</p>\r\n<p>Watch <span class="clr-blue"> <a>How it Works or Take the Tour &gt;&gt; </a></span></p>\r\n<p>Lorem Ipsum is simply dummy  text of the printing and typesetting industry. Lorem Ipsum has been the  industry''s standard dummy text ever since the 1500s, when an unknown  printer took a galley of type and scrambled it to make a t</p>\r\n<p><span class="clr-blue"><a>Start raising money now &gt;&gt;</a></span></p>\r\n</div>\r\n</div>', 1, '2014-08-04 20:42:58'),
(60, 'collage', ' How does it work? ', 0, '<div class="panel-collapse collapse in" id="collapseOne">\r\n<div class="panel-body">\r\n<p>Lorem Ipsum is simply dummy  text of the printing and typesetting industry. Lorem Ipsum has been the  industry''s standard dummy text ever since the 1500s, when an unknown  printer took a galley of type and scrambled it to make a t</p>\r\n<p>Watch <span class="clr-blue"> <a>How it Works or Take the Tour &gt;&gt; </a></span></p>\r\n<p>Lorem Ipsum is simply dummy  text of the printing and typesetting industry. Lorem Ipsum has been the  industry''s standard dummy text ever since the 1500s, when an unknown  printer took a galley of type and scrambled it to make a t</p>\r\n<p><span class="clr-blue"><a>Start raising money now &gt;&gt;</a></span></p>\r\n</div>\r\n</div>', 1, '2014-08-05 11:04:31'),
(61, 'collage', ' How does it work? ', 60, '<div class="panel-collapse collapse in" id="collapseOne">\r\n<div class="panel-body">\r\n<p>Lorem Ipsum is simply dummy  text of the printing and typesetting industry. Lorem Ipsum has been the  industry''s standard dummy text ever since the 1500s, when an unknown  printer took a galley of type and scrambled it to make a t</p>\r\n<p>Watch <span class="clr-blue"> <a>How it Works or Take the Tour &gt;&gt; </a></span></p>\r\n<p>Lorem Ipsum is simply dummy  text of the printing and typesetting industry. Lorem Ipsum has been the  industry''s standard dummy text ever since the 1500s, when an unknown  printer took a galley of type and scrambled it to make a t</p>\r\n<p><span class="clr-blue"><a>Start raising money now &gt;&gt;</a></span></p>\r\n</div>\r\n</div>', 1, '2014-08-05 11:05:42');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE IF NOT EXISTS `settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `discription` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `type`, `name`, `discription`) VALUES
(1, 'Footer', 'Footer Text', 'Â© 2013-2014 GoFundMe.');

-- --------------------------------------------------------

--
-- Table structure for table `socialsettings`
--

CREATE TABLE IF NOT EXISTS `socialsettings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `url` varchar(50) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `socialsettings`
--

INSERT INTO `socialsettings` (`id`, `name`, `url`, `status`) VALUES
(5, 'Facebook', 'https://www.facebook.com', 1),
(6, 'Twitter', 'https://twitter.com', 1),
(7, 'Linked In', 'https://www.linkedin.com/', 1),
(9, 'Google', 'https://plus.google.com', 1);

-- --------------------------------------------------------

--
-- Table structure for table `static_pages`
--

CREATE TABLE IF NOT EXISTS `static_pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page_title` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `page_description` longtext NOT NULL,
  `meta_keyword` varchar(255) NOT NULL,
  `meta_description` varchar(255) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `page_title` (`page_title`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=66 ;

--
-- Dumping data for table `static_pages`
--

INSERT INTO `static_pages` (`id`, `page_title`, `alias`, `page_description`, `meta_keyword`, `meta_description`, `status`, `created`, `modified`) VALUES
(56, 'How It Works', 'tour', '<!-- /* Content section starts */ -->\r\n<div class="is-section is-content-section">\r\n<div class="container min-height-help work">\r\n<div class="row">\r\n<div class="col-md-3 col-sm-3 b-right b-right-work">\r\n<div class="leftsidebar">\r\n<h4 class="page-title tUpper t-grey tBold dP-all-s noMargin">IMPORTANT PAGES</h4>\r\n<ul class="nav">\r\n    <li class="active"><a href="http://softprodigy.in/GoFundMe/tour">How it works</a></li>\r\n    <li><a href="http://softprodigy.in/GoFundMe/users/success">Success stories</a></li>\r\n    <li><a href="http://softprodigy.in/GoFundMe/static/faq">Help</a></li>\r\n    <li><a href="http://softprodigy.in/GoFundMe/static/questions">Questions</a></li>\r\n    <li><a href="http://softprodigy.in/GoFundMe/about_us">About Us</a></li>\r\n</ul>\r\n</div>\r\n</div>\r\n<div class="col-md-9 col-sm-9 b-left-new"><!-- /* Content area start */ -->\r\n<div class="content-area-stories content-area-mg content-work ">\r\n<div class="help-title"><span class="txt-help">Step 1</span></div>\r\n<div class="work-block">\r\n<div class="arrow">&nbsp;</div>\r\n<div class="content aCenter">\r\n<h1>Create Your Campaign</h1>\r\n<p>Let''s get started by filling out the basic fundraiser information.</p>\r\n<img alt="" src="img/work-1.png" class="img-responsive" /></div>\r\n<div class="help-title tMxxxl"><span class="txt-help">Step 2</span></div>\r\n<div class="work-block">\r\n<div class="arrow">&nbsp;</div>\r\n<div class="content aCenter">\r\n<h1>Share Your Campaign</h1>\r\n<p>Our built-in connections to Facebook, Twitter &amp; Email make sharing a breeze.</p>\r\n<img alt="" src="img/work-2.png" class="img-responsive" /></div>\r\n<div class="help-title  tMxxxl"><span class="txt-help">Step 3</span></div>\r\n<div class="work-block">\r\n<div class="arrow">&nbsp;</div>\r\n<div class="content aCenter">\r\n<h1>Easily Accept Donations</h1>\r\n<p>Receive your money by requesting a check or bank transfer.</p>\r\n<img alt="" src="img/work-3.png" class="img-responsive" /></div>\r\n<div class="help-title  tMxxxl"><span class="txt-help">Step 4</span></div>\r\n<div class="work-block">\r\n<div class="arrow">&nbsp;</div>\r\n<div class="content aCenter">\r\n<h1>Enjoy the Results</h1>\r\n<p>Make changes, post updates and send thank-you notes from your dashboard.</p>\r\n<img alt="" src="img/work-4.png" class="img-responsive" /></div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n<!-- /* Content area stories ends */ --></div>\r\n<!-- /* col-md-9 */ --></div>\r\n</div>\r\n</div>\r\n<!-- /* Content section ends  */ -->                    <!--<div class="is-section is-bottom-section">\r\n        <div class="container"> \r\n            <div class="row">\r\n                <div class="col-md-6 col-sm-6">\r\n                    <div class="displayB campaign-fb">\r\n                        <h4>Easily Find Campaigns</h4>\r\n                        <p>See what your friends support and help spread the word!</p>\r\n                    </div>\r\n                </div>\r\n                \r\n                <div class="col-md-6 col-sm-6">\r\n                    <div class="displayB campaign-btn">\r\n                        <a href=""><img src="img/funded-by-friends.png" class="img-responsive"></a>\r\n                    </div>\r\n                </div>\r\n                \r\n            </div>\r\n        </div>\r\n    </div>-->          <!-- /* Footer section starts / Section last */ -->', 'How it works', 'This page details how it works.', 1, '2014-07-24 11:11:06', '2014-09-29 16:46:24'),
(57, 'Ask a Question', 'ask_a_question', '<p>Ask a question about Go fund me.</p>', '', '', 1, '2014-07-28 12:45:39', '2014-07-28 12:57:20'),
(59, 'Common Questions', 'questions', '<p><strong>page comming soon..........</strong></p>', 'Common Questions', 'Common Questions', 1, '2014-07-29 14:24:36', '2014-07-29 14:24:36'),
(60, 'Asked Questions', 'contact', '<p><strong>page somming soon......</strong></p>', 'Frequently Asked Questions ', 'Frequently Asked Questions ', 1, '2014-07-29 14:26:47', '2014-07-29 14:26:47'),
(55, 'Privacy', 'privacy', '<h1><style type="text/css">\r\n.left_side_inner p {\r\n    color: #5D5D5D;\r\n    float: left;\r\n    font-family: Arial,Helvetica,sans-serif;\r\n    font-size: 14px;\r\n    line-height: 25px;\r\n    margin: 10px 0;\r\n    width: 100</style><strong>Privacy</strong></h1>\r\n<p>This privacy policy tells you how we use personal information collected at this site. Please read this         privacy policy before using the site or submitting any personal information. By using the site, you are         accepting the practices described in this privacy policy. You are encouraged to review the privacy policy         whenever you visit the site to make sure that you understand how any personal information you provide will         be used. Note: the privacy practices set forth in this privacy policy are for this web site only. If you         link to other web sites, please review the privacy policies posted at those sites.</p>', 'privacy', 'privacy', 1, '2014-04-17 14:58:47', '2014-07-22 12:46:06'),
(46, 'About Us', 'about_us', '<div class="is-section is-banner-section article-detail">\r\n<div class="container-fluid">\r\n<div data-ride="carousel" class="carousel slide" id="carousel-example-generic"><!-- Wrapper for slides -->\r\n<div class="carousel-inner">\r\n<div class="item active"><img alt="image 1" src="img/category-listing-banner.png" />\r\n<div class="banner-head">\r\n<h2>About Us</h2>\r\n<p>Bacon ipsum dolor sit amet pancetta frankfurter swine spare ribs drumstick, andouille pastrami turkey pig brisket short loin filet mignon ball tip.</p>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n<!-- /* Content section starts */ -->\r\n<div class="is-section is-content-section">\r\n<div class="container min-height-help help">\r\n<div class="row">\r\n<div class="col-md-12">&nbsp;</div>\r\n</div>\r\n<div class="row">\r\n<div class="col-md-3 col-sm-3 b-right b-right-aboutus">\r\n<div class="leftsidebar">\r\n<h4 class="page-title tUpper t-grey tBold dP-all-s noMargin">IMPORTANT PAGES</h4>\r\n<ul class="nav">\r\n    <li ><a href="http://softprodigy.in/GoFundMe/tour">How it works</a></li>\r\n    <li><a href="http://softprodigy.in/GoFundMe/users/success">Success stories</a></li>\r\n    <li><a href="http://softprodigy.in/GoFundMe/static/faq">Help</a></li>\r\n    <li><a href="http://softprodigy.in/GoFundMe/static/questions">Questions</a></li>\r\n    <li class="active"><a href="http://softprodigy.in/GoFundMe/about_us">About Us</a></li>\r\n</ul>\r\n</div>\r\n</div>\r\n<div class="col-md-9 col-sm-9"><!-- /* Content area start */ -->\r\n<div class="content-area cst-content-padd">\r\n<div class="help-title"><span><span class="txt-about">Overview</span></span></div>\r\n<div class="overview tMxxx">\r\n<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec odio. Quisque volutpat mattis eros. Nullam malesuada erat ut turpis. Suspendisse urna nibh, viverra non, semper suscipit, posuere a, pede.Donec nec justo eget felis facilisis fermentum. Aliquam porttitor mauris sit amet orci. Aenean dignissim pellentesque felis.</p>\r\n</div>\r\n<div class="help-title"><span><span class="txt-about">Key Points</span></span></div>\r\n<div class="key-points tMxxx">\r\n<div class="col-md-12 points-c">\r\n<div class="col-md-6 key-list">\r\n<ul>\r\n    <li>$370M raised from 6M donors</li>\r\n    <li>$370M raised from 6M donors</li>\r\n    <li>$370M raised from 6M donors</li>\r\n</ul>\r\n</div>\r\n<div class="col-md-6 key-list">\r\n<ul>\r\n    <li>$370M raised from 6M donors</li>\r\n    <li>$370M raised from 6M donors</li>\r\n    <li>$370M raised from 6M donors</li>\r\n</ul>\r\n</div>\r\n</div>\r\n</div>\r\n<div class="help-title"><span><span class="txt-about">Top 5 Questions</span></span></div>\r\n<div class="questions tMxxx">\r\n<ul>\r\n    <li>What is GoFundMe all about?</li>\r\n    <li>How much does it cost to use GoFundMe?</li>\r\n    <li>Why does GoFundMe have to charge 5%?</li>\r\n    <li>How does GoFundMe guarantee the authenticity of every campaign?</li>\r\n    <li>What are the most popular ways people use GoFundMe?</li>\r\n</ul>\r\n</div>\r\n<div class="form-group cst-frm">\r\n<div class=" col-sm-10 aLeft"><button class="btn btn-default btn-history" type="submit">Company History</button></div>\r\n</div>\r\n</div>\r\n<!-- /* Content area ends */ --></div>\r\n</div>\r\n</div>\r\n</div>\r\n<!-- /* Content section ends  */ -->                    <!--<div class="is-section is-bottom-section">\r\n        <div class="container"> \r\n            <div class="row">\r\n                <div class="col-md-6 col-sm-6">\r\n                    <div class="displayB campaign-fb">\r\n                        <h4>Easily Find Campaigns</h4>\r\n                        <p>See what your friends support and help spread the word!</p>\r\n                    </div>\r\n                </div>\r\n                \r\n                <div class="col-md-6 col-sm-6">\r\n                    <div class="displayB campaign-btn">\r\n                        <a href=""><img src="img/funded-by-friends.png" class="img-responsive"></a>\r\n                    </div>\r\n                </div>\r\n                \r\n            </div>\r\n        </div>\r\n    </div>-->          <!-- /* Footer section starts / Section last */ -->', 'About Us', 'About Us Description', 1, '2013-04-13 01:41:23', '2014-09-29 16:48:00'),
(61, 'Help', 'help', '<p><strong>page comming soon............<br />\r\n</strong></p>', 'help', 'help', 1, '2014-07-29 16:29:11', '2014-07-29 16:29:11'),
(62, 'Pricing Fees', 'pricing', '<p>Page comming soon.....</p>', 'pricing', 'pricing', 1, '2014-07-30 19:31:03', '2014-07-30 19:31:03'),
(63, 'Fundraising Ideas', 'ideas', '<p>Page comming soon.....</p>', 'Fundraising Ideas', 'Fundraising Ideas', 1, '2014-08-01 11:23:49', '2014-08-01 11:23:49'),
(64, 'GoFundMe Reviews', 'review', '<p>Page comming soon.....</p>', 'GoFundMe Reviews', 'GoFundMe Reviews', 1, '2014-08-01 11:24:35', '2014-08-01 11:24:35'),
(65, 'TESTING PAGE', 'testing', '<p>&nbsp;<span style="font-family: Arial, Helvetica, sans; font-size: 11px; line-height: 14px; text-align: justify;">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas euismod, dolor in mollis semper, purus felis blandit nibh, ut sollicitudin sem diam nec lectus. Donec tincidunt lobortis est, dapibus mollis lectus congue ac. Vestibulum sed massa arcu. Proin venenatis accumsan dapibus. Maecenas sagittis ullamcorper adipiscing. Duis dapibus eget mauris in ornare. Etiam faucibus velit quis orci tristique, bibendum imperdiet magna elementum. Pellentesque fringilla urna id lacus sollicitudin blandit. Proin et justo et est commodo adipiscing sit amet nec arcu. Ut in elit ac ante dapibus cursus. Nulla bibendum lorem quis volutpat ullamcorper. Mauris bibendum fermentum nibh. Proin facilisis ligula ipsum, convallis sodales dolor sagittis non.</span></p>\r\n<p style="text-align: justify; font-size: 11px; line-height: 14px; margin: 0px 0px 14px; padding: 0px; font-family: Arial, Helvetica, sans;">Quisque quis varius leo. Maecenas sed nunc molestie, pellentesque lacus nec, egestas quam. Vivamus vel ipsum vitae velit elementum cursus sit amet sit amet justo. Suspendisse at libero dictum, auctor lorem eget, dapibus ligula. Sed a lacus euismod, gravida tellus eget, tincidunt ante. Proin non nunc id massa placerat commodo ac in magna. Donec sagittis a purus sed volutpat. Aliquam dapibus laoreet justo ac faucibus. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam bibendum, velit a facilisis tincidunt, est purus tempor felis, non consectetur ipsum eros tincidunt nisl.</p>\r\n<p style="text-align: justify; font-size: 11px; line-height: 14px; margin: 0px 0px 14px; padding: 0px; font-family: Arial, Helvetica, sans;">Nunc quis volutpat elit. Sed rutrum mi ligula, ac dapibus quam suscipit sit amet. Nullam eu fermentum tortor. Aenean quis faucibus nulla, vehicula malesuada diam. Donec augue ligula, vulputate in aliquet id, blandit in dolor. Nullam et sodales metus. Vivamus auctor eget dui ac accumsan. Donec tempus sed justo quis tincidunt. Aenean venenatis ultrices varius. Nunc non felis ultricies, condimentum orci sed, tincidunt lorem. Cras sed est tempus, pulvinar libero et, egestas orci.</p>\r\n<p style="text-align: justify; font-size: 11px; line-height: 14px; margin: 0px 0px 14px; padding: 0px; font-family: Arial, Helvetica, sans;">Vivamus eu gravida ante. Aenean aliquet sapien turpis, a accumsan leo laoreet eu. Sed vehicula ipsum sem, sit amet malesuada nisi bibendum in. Integer volutpat fringilla urna placerat condimentum. Aliquam porta, ante a semper congue, erat ante varius ligula, ac gravida turpis tortor at justo. Nulla facilisi. Phasellus vitae ante magna. Nullam quis felis sapien.</p>\r\n<p style="text-align: justify; font-size: 11px; line-height: 14px; margin: 0px 0px 14px; padding: 0px; font-family: Arial, Helvetica, sans;">Nullam vestibulum euismod sem id placerat. Aliquam et elementum metus. Cras a ante faucibus, ullamcorper erat sit amet, mattis ligula. Aenean et tincidunt orci. Phasellus dapibus elementum orci, nec feugiat justo adipiscing eget. Cras laoreet massa est, et adipiscing orci rutrum vitae. Nullam et nisi aliquam massa faucibus lobortis. Proin ac consectetur mi, vulputate consequat odio.</p>', 'testing', 'testing', 1, '2014-08-13 17:34:44', '2014-08-13 17:34:44'),
(51, 'Terms and Conditions', 'terms', '<p><style type="text/css">\r\n.left_side_inner p {\r\n    color: #5D5D5D;\r\n    float: left;\r\n    font-family: Arial,Helvetica,sans-serif;\r\n    font-size: 14px;\r\n    line-height: 25px;\r\n    margin: 10px 0;\r\n    width: 100%;</style><strong>Terms and Conditions</strong></p>', 'tearm', 'tearm', 1, '2013-08-19 21:03:19', '2014-07-22 12:37:49');

-- --------------------------------------------------------

--
-- Table structure for table `tempdonations`
--

CREATE TABLE IF NOT EXISTS `tempdonations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `article_id` int(11) NOT NULL,
  `amount` int(255) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `hideinfo` tinyint(4) NOT NULL,
  `email` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `zip` bigint(20) NOT NULL,
  `image` varchar(255) NOT NULL,
  `comment` text NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=224 ;

--
-- Dumping data for table `tempdonations`
--

INSERT INTO `tempdonations` (`id`, `article_id`, `amount`, `firstname`, `lastname`, `hideinfo`, `email`, `country`, `zip`, `image`, `comment`, `date`) VALUES
(129, 125, 100, 'ashwani', 'kaushal', 0, 'ashwanik.softprodigy@gmail.com', 'india', 140124, '', '', '2014-08-25 20:45:05'),
(130, 125, 100, 'ashwani', 'kaushal', 0, 'ashwanik.softprodigy@gmail.com', 'india', 140124, '', '', '2014-08-25 20:45:17'),
(131, 125, 100, 'ashwani', 'kaushal', 0, 'ashwanik.softprodigy@gmail.com', 'india', 140124, '', '', '2014-08-25 21:14:49'),
(132, 123, 100, 'ashwani', 'kaushal', 0, 'ashwanik.softprodigy@gmail.com', 'india', 140124, '', '', '2014-08-26 19:52:12'),
(133, 123, 100, 'ashwani', 'kaushal', 0, 'ashwanik.softprodigy@gmail.com', 'india', 140124, '', '', '2014-08-26 20:12:50'),
(134, 123, 100, 'ashwani', 'kaushal', 0, 'ashwanik.softprodigy@gmail.com', 'india', 140124, '', '', '2014-08-26 20:13:51'),
(135, 124, 100, 'ashwani', 'kaushal', 0, 'india@gmail.com', 'indai', 12345, '', '', '2014-08-27 23:45:19'),
(136, 125, 100, 'ashwani', 'kaushal', 0, 'india@gmail.com', 'indai', 12345, '', '', '2014-08-28 10:30:45'),
(137, 127, 0, '', '', 0, '', '', 0, '', '', '2014-08-29 15:06:49'),
(138, 127, 0, '', '', 0, '', '', 0, '', '', '2014-08-29 15:08:39'),
(139, 130, 0, '', '', 0, '', '', 0, '', '', '2014-09-02 19:04:56'),
(140, 130, 100, 'ashwani', 'kaushal', 0, 'india@gmail.com', 'indai', 12345, 'user_1409665749_control-left.png', '', '2014-09-02 19:19:09'),
(141, 126, 100, 'ashwani', 'kaushal', 0, 'ashwanik.softprodigy@gmail.com', 'indai', 200200, '', '', '2014-09-02 19:26:19'),
(142, 126, 100, 'ashwani', 'kaushal', 0, 'ashwanik.softprodigy@gmail.com', 'indai', 200200, '', '', '2014-09-02 19:26:34'),
(143, 126, 100, 'ashwani', 'kaushal', 0, 'ashwanik.softprodigy@gmail.com', 'indai', 200200, 'user_1409667009_email.png', '', '2014-09-02 19:40:09'),
(144, 126, 100, 'ashwani', 'kaushal', 0, 'ashwanik.softprodigy@gmail.com', 'indai', 200200, 'user_1409667020_article-created.png', '', '2014-09-02 19:40:20'),
(145, 128, 100, 'ashwani', 'kaushal', 0, 'ashwanik.softprodigy@gmail.com', '1', 200200, '', '', '2014-09-04 10:36:59'),
(146, 127, 10, 'Raj', 'Dhiman', 0, 'raj.softprodigy@gmail.com', '105', 160055, '', 'Comment', '2014-09-05 18:00:32'),
(147, 127, 100, 'Raj', 'Dhiman', 0, 'raj.softprodigy@gmail.com', '105', 160055, '', 'Comment', '2014-09-05 18:04:15'),
(148, 127, 100, 'Raj', 'Dhiman', 0, 'raj.softprodigy@gmail.com', '105', 160055, '', 'Comment', '2014-09-05 18:18:26'),
(149, 140, 100, 'Jayant', 'Sharma', 0, 'jayant123sharma@hotmail.com', '233', 160055, 'user_1410420390_image002-732513.png', 'Hey guys, Plz donate.', '2014-09-11 12:56:30'),
(150, 140, 50, 'Jayant', 'Sharma', 0, 'jayant123sharma@hotmail.com', '233', 160055, 'user_1410420739_image002-732513.png', 'Hey guys, Plz donate.', '2014-09-11 13:02:19'),
(151, 140, 100, 'Jayant', 'Sharma', 0, 'jayant123sharma@hotmail.com', '233', 160055, 'user_1410420755_image002-732513.png', 'Hey guys, Plz donate.', '2014-09-11 13:02:35'),
(152, 140, 400, 'Kanchan', 'Grover', 0, 'kanchan.softprodigy@gmail.com', '233', 21223, 'user_1410421659_d.jpg', 'megadeth..', '2014-09-11 13:17:39'),
(153, 140, 100, 'deepak', 'sharma', 0, 'deepak@gmail.com', '1', 124140, '', '', '2014-09-11 22:18:27'),
(154, 140, 100, 'deepak', 'sharma', 0, 'deepak@gmail.com', '3', 124140, '', '', '2014-09-12 13:02:33'),
(155, 140, 100, 'ashwani', 'kaushal', 0, 'ashwanik.softprodigy@gmail.com', '1', 12345, '', 'hope for well!!!!!', '2014-09-12 20:07:34'),
(156, 140, 455142, 'Deepak', 'Kumar', 0, 'deepak@gmail.com', '105', 160101, '', 'sdfgefdhfg', '2014-09-15 15:54:35'),
(157, 140, 100, 'ashwani', 'kaushal', 0, 'ashwanik.softprodigy@gmail.com', '105', 12345, '', 'comment...', '2014-09-15 19:12:28'),
(158, 140, 100, 'ashwani', 'kaushal', 0, 'ashwanik.softprodigy@gmail.com', '105', 12345, '', '..', '2014-09-15 19:26:45'),
(159, 140, 100, 'ashwani', 'kaushal', 0, 'ashwanik.softprodigy@gmail.com', '105', 12345, '', '..', '2014-09-15 19:32:57'),
(160, 140, 100, 'ashwani', 'kaushal', 0, 'ashwanik.softprodigy@gmail.com', '105', 12345, '', '..', '2014-09-15 19:34:36'),
(161, 140, 100, 'ashwani', 'kaushal', 0, 'ashwanik.softprodigy@gmail.com', '105', 12345, '', '..', '2014-09-15 19:36:08'),
(162, 140, 100, 'ashwani', 'kaushal', 0, 'ashwanik.softprodigy@gmail.com', '105', 12345, '', '..', '2014-09-15 19:36:37'),
(163, 140, 100, 'ashwani', 'kaushal', 0, 'ashwanik.softprodigy@gmail.com', '105', 12345, '', '..', '2014-09-15 19:37:07'),
(164, 140, 100, 'ashwani', 'kaushal', 0, 'ashwanik.softprodigy@gmail.com', '104', 12345, '', 'gdkjhs', '2014-09-15 19:49:58'),
(165, 140, 100, 'ashwani', 'kaushal', 0, 'ashwanik.softprodigy@gmail.com', '105', 12345, '', 'gdf', '2014-09-15 20:12:06'),
(166, 140, 100, 'ashwani', 'kaushal', 0, 'ashwanik.softprodigy@gmail.com', '105', 12345, '', 'gdf', '2014-09-15 20:13:00'),
(167, 140, 100, 'ashwani', 'kaushal', 0, 'ashwanik.softprodigy@gmail.com', '105', 12345, '', 'gdf', '2014-09-15 20:14:24'),
(168, 140, 100, 'ashwani', 'kaushal', 1, 'ashwanik.softprodigy@gmail.com', '105', 12345, '', 'gdf', '2014-09-15 20:17:55'),
(169, 140, 100, 'ashwani', 'kaushal', 1, 'ashwanik.softprodigy@gmail.com', '105', 12345, '', 'test donation..', '2014-09-15 20:24:28'),
(170, 140, 10, 'ashwani', 'kaushal', 1, 'ghgfhgh@gmail.com', '105', 12345, '', 'Good!!!!', '2014-09-16 11:51:57'),
(171, 140, 101, 'ashwani', 'kaushal', 1, 'ashwanik.softprodigy@gmail.com', '105', 12345, '', 'jdskjas', '2014-09-16 13:11:12'),
(172, 140, 201, 'ashwani', 'kaushal', 1, 'ashwanik.softprodigy@gmail.com', '105', 123456, '', 'hdhh', '2014-09-16 13:29:51'),
(173, 140, 2147483647, 'jkdfhkhdfjgh', 'djkshgsdhjkfsdm', 1, 'jsdfabksdkfsd@gmail.com', '101', 15351, '', 'wejkhrjkweghfksef', '2014-09-18 13:29:37'),
(174, 140, 5000, 'Gaurav', 'Saini', 0, 'gauravsoftprodigy1@gmail.com', '105', 160055, '', 'Money for the Good Cause', '2014-09-22 14:31:15'),
(175, 140, 5000, 'Gaurav', 'Saini', 1, 'gauravsoftprodigy1@gmail.com', '105', 160055, '', 'Testing', '2014-09-22 14:51:52'),
(176, 141, 3000, 'Kanchan', 'Grover', 0, 'kanchan.softprodigy@gmail.com', '105', 160055, '', 'dfghdfgdfg', '2014-09-22 19:09:13'),
(177, 140, 100, 'ashwani', 'kaushal', 0, 'ash@gmail.com', '101', 12345, '', '...', '2014-09-29 15:32:25'),
(178, 143, 100, 'raj', 'dhiman', 0, 'raj_dhiman@softprodigy.com', '105', 12345, '', 'Hope for well!', '2014-10-10 18:16:51'),
(179, 140, 100, 'ashwani', 'kaushal', 0, 'ashwanik.softprodigy@gmail.com', '105', 140124, '', 'hope for well!', '2014-10-15 14:29:52'),
(180, 140, 1, 'pardeep', 'grover', 0, 'pardeep@gmail.com', '105', 12345, '', 'fd', '2014-10-16 20:52:18'),
(181, 140, 91, 'pardeep', 'grover', 0, 'pardeep@gmail.com', '105', 12345, '', 'fd', '2014-10-16 21:12:16'),
(182, 140, 91, 'pardeep', 'grover', 0, 'pardeep@gmail.com', '105', 12345, '', 'fd', '2014-10-16 21:26:59'),
(183, 140, 500, 'rajj', 'dhiman', 0, 'raj_dhiman@softprodigy.com', '105', 12345, '', 'sdf', '2014-10-18 12:54:13'),
(184, 140, 500, 'rajj', 'dhiman', 0, 'raj_dhiman@softprodigy.com', '105', 12345, '', 'sdf', '2014-10-18 12:56:31'),
(185, 140, 500, 'rajj', 'dhiman', 0, 'raj_dhiman@softprodigy.com', '105', 12345, '', 'sdf', '2014-10-18 12:56:49'),
(186, 140, 500, 'rajj', 'dhiman', 0, 'raj_dhiman@softprodigy.com', '105', 12345, '', 'sdf', '2014-10-18 12:58:46'),
(187, 140, 100, 'rajj', 'dhiman', 0, 'raj_dhiman@softprodigy.com', '105', 12345, '', 'sdf', '2014-10-18 13:03:09'),
(188, 140, 3, 'rajj', 'dhiman', 0, 'raj_dhiman@softprodigy.com', '105', 12345, '', 'sdf', '2014-10-18 13:05:37'),
(189, 140, 1, 'rajj', 'dhiman', 0, 'raj_dhiman@softprodigy.com', '105', 12345, '', 'sdf', '2014-10-18 13:07:02'),
(190, 140, 1, 'rajj', 'dhiman', 0, 'raj_dhiman@softprodigy.com', '105', 12345, '', 'sdf', '2014-10-18 13:07:20'),
(191, 140, 2, 'rajj', 'dhiman', 0, 'raj_dhiman@softprodigy.com', '105', 12345, '', 'sdf', '2014-10-18 13:07:38'),
(192, 140, 1, 'rajj', 'dhiman', 0, 'raj_dhiman@softprodigy.com', '105', 12345, '', 'sdf', '2014-10-18 13:09:50'),
(193, 140, 1, 'rajj', 'dhiman', 0, 'raj_dhiman@softprodigy.com', '105', 12345, '', 'sdf', '2014-10-18 13:20:21'),
(194, 140, 1, 'rajj', 'dhiman', 0, 'raj_dhiman@softprodigy.com', '105', 12345, '', 'sdf', '2014-10-18 13:20:52'),
(195, 140, 500, 'rajj', 'dhiman', 0, 'raj_dhiman@softprodigy.com', '105', 12345, '', 'sdf', '2014-10-18 13:23:55'),
(196, 140, 100, 'rajj', 'dhiman', 0, 'raj_dhiman@softprodigy.com', '105', 12345, '', 'sdf', '2014-10-18 13:26:38'),
(197, 140, 1000, 'ashwani', 'kaishal', 0, 'ash@gmail.com', '105', 12345, '', 'sds', '2014-10-18 13:31:07'),
(198, 140, 100, 'ashwani', 'kaishal', 0, 'ash@gmail.com', '105', 12345, '', 'sds', '2014-10-18 13:43:37'),
(199, 140, 100, 'ashwani', 'kaishal', 0, 'ash@gmail.com', '105', 12345, '', 'sds', '2014-10-18 13:43:55'),
(200, 140, 100, 'ashwani', 'kaishal', 0, 'ash@gmail.com', '105', 12345, '', 'sds', '2014-10-18 13:44:22'),
(201, 140, 100, 'ashwani', 'kaishal', 0, 'ash@gmail.com', '105', 12345, '', 'sds', '2014-10-18 13:44:40'),
(202, 140, 100, 'ashwani', 'kaishal', 0, 'ash@gmail.com', '105', 12345, '', 'sds', '2014-10-18 13:46:50'),
(203, 140, 100, 'ashwani', 'kaishal', 0, 'ash@gmail.com', '105', 12345, '', 'sds', '2014-10-18 13:48:02'),
(204, 140, 200, 'ashwani', 'kaishal', 0, 'ash@gmail.com', '105', 12345, '', 'sds', '2014-10-18 13:51:28'),
(205, 140, 1000, 'ashwani', 'kaishal', 0, 'ash@gmail.com', '105', 12345, '', 'sds', '2014-10-18 13:53:19'),
(206, 140, 10000, 'ashwani', 'kaishal', 0, 'ash@gmail.com', '105', 12345, '', 'sds', '2014-10-18 13:54:45'),
(207, 140, 10000, 'ashwani', 'kaishal', 0, 'ash@gmail.com', '105', 12345, '', 'sds', '2014-10-18 13:58:15'),
(208, 140, 100, 'arjun', 'arjun', 1, 'arjun@gmail.com', '105', 140124, '', 'hj', '2014-10-18 14:22:05'),
(209, 152, 100, 'anit', 'amit', 0, 'pardeepbuz@gmail.com', '105', 12345, '', 'Done!', '2014-10-22 15:28:56'),
(210, 152, 100, 'ashwani', 'kaushal', 0, 'ashwanik@gmail.com', '105', 12345, '', 'Done!', '2014-10-22 15:42:21'),
(211, 152, 100, 'sadas', 'sdasd', 0, 'sdsad@gmail.com', '105', 12345, '', 'done!', '2014-10-22 15:45:12'),
(212, 152, 100, 'sdefsf', 'dsfdsf', 0, 'dsfds@gmail.com', '18', 12345, '', 'desf', '2014-10-22 15:48:17'),
(213, 140, 100, 'rajj', 'dhiman', 0, 'raj_dhiman@softprodigy.com', '1', 45646456456, '', '', '2014-11-05 13:05:18'),
(214, 140, 100, 'rajj', 'dhiman', 0, 'raj_dhiman@softprodigy.com', '1', 45646456456, '', '', '2014-11-05 13:05:53'),
(215, 140, 100, 'rajj', 'dhiman', 0, 'raj_dhiman@softprodigy.com', '1', 45646456456, '', 'sadsa', '2014-11-05 13:06:35'),
(216, 153, 100, 'rajj', 'dhiman', 1, 'raj_dhiman@softprodigy.com', '1', 12345, '', '', '2014-11-05 13:07:12'),
(217, 147, 100, 'rajj', 'dhiman', 1, 'raj_dhiman@softprodigy.com', '1', 12345, '', '', '2014-11-05 13:09:45'),
(218, 147, 100, 'rajj', 'dhiman', 1, 'raj_dhiman@softprodigy.com', '1', 12345, '', '', '2014-11-05 13:21:21'),
(219, 147, 100, 'rajj', 'dhiman', 1, 'raj_dhiman@softprodigy.com', '1', 12345, '', '', '2014-11-05 13:24:07'),
(220, 147, 100, 'ashwani', 'kaushal', 0, 'ashwanik.softprodigy@gmail.com', '2', 140124, '', '', '2014-11-05 14:56:47'),
(221, 147, 100, 'ashwani', 'kaushal', 0, 'ashwanik.softprodigy@gmail.com', '2', 140124, '', '', '2014-11-05 15:01:22'),
(222, 147, 100, 'ashwani', 'kaushal', 0, 'ashwanik.softprodigy@gmail.com', '2', 140124, '', '', '2014-11-05 15:44:08'),
(223, 156, 100, 'anit', 'amit', 0, 'sharma.akshat3184@yahoo.com', '2', 12345, '', '', '2014-11-05 16:21:27');

-- --------------------------------------------------------

--
-- Table structure for table `tempphotoimages`
--

CREATE TABLE IF NOT EXISTS `tempphotoimages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `album_id` int(11) NOT NULL,
  `images` varchar(255) NOT NULL,
  `user_id` int(11) NOT NULL COMMENT 'posted on',
  `date` date NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=97 ;

--
-- Dumping data for table `tempphotoimages`
--

INSERT INTO `tempphotoimages` (`id`, `album_id`, `images`, `user_id`, `date`, `modified_date`) VALUES
(1, 0, 'pic_1399128708_image.php2.jpg', 14, '0000-00-00', '2014-05-03 20:21:48'),
(2, 0, 'pic_1399128709_image.php1.jpg', 14, '0000-00-00', '2014-05-03 20:21:49'),
(3, 0, 'pic_1399128709_image.php.jpg', 14, '0000-00-00', '2014-05-03 20:21:49'),
(4, 0, 'pic_1399128709_yuvi.jpg', 14, '0000-00-00', '2014-05-03 20:21:49'),
(5, 0, 'pic_1399128822_yuvi.jpg', 14, '0000-00-00', '2014-05-03 20:23:42'),
(6, 0, 'pic_1399128822_yuvraj_singh.jpg', 14, '0000-00-00', '2014-05-03 20:23:42'),
(7, 0, 'pic_1399128843_yuvi.jpg', 14, '0000-00-00', '2014-05-03 20:24:03'),
(8, 0, 'pic_1399128843_yuvraj_singh.jpg', 14, '0000-00-00', '2014-05-03 20:24:03'),
(9, 0, 'pic_1399129059_image.php2.jpg', 14, '0000-00-00', '2014-05-03 20:27:39'),
(10, 0, 'pic_1399129059_image.php1.jpg', 14, '0000-00-00', '2014-05-03 20:27:39'),
(11, 0, 'pic_1399129060_image.php.jpg', 14, '0000-00-00', '2014-05-03 20:27:40'),
(12, 0, 'pic_1399129135_yuvi.jpg', 14, '0000-00-00', '2014-05-03 20:28:55'),
(13, 0, 'pic_1399129135_yuvraj_singh.jpg', 14, '0000-00-00', '2014-05-03 20:28:55'),
(14, 0, 'pic_1399129156_image.php2.jpg', 14, '0000-00-00', '2014-05-03 20:29:16'),
(15, 0, 'pic_1399129784_image.php2.jpg', 14, '0000-00-00', '2014-05-03 20:39:44'),
(16, 0, 'pic_1399129784_image.php1.jpg', 14, '0000-00-00', '2014-05-03 20:39:44'),
(17, 0, 'pic_1399129784_image.php.jpg', 14, '0000-00-00', '2014-05-03 20:39:44'),
(18, 0, 'pic_1399129785_yuvi.jpg', 14, '0000-00-00', '2014-05-03 20:39:45'),
(19, 0, 'pic_1399129785_yuvraj_singh.jpg', 14, '0000-00-00', '2014-05-03 20:39:45'),
(20, 0, 'pic_1399131276_image.php2.jpg', 14, '0000-00-00', '2014-05-03 21:04:36'),
(21, 0, 'pic_1399131276_image.php1.jpg', 14, '0000-00-00', '2014-05-03 21:04:36'),
(22, 0, 'pic_1399131950_image.php2.jpg', 14, '0000-00-00', '2014-05-03 21:15:50'),
(23, 0, 'pic_1399131950_image.php.jpg', 14, '0000-00-00', '2014-05-03 21:15:50'),
(24, 0, 'pic_1399273367_image.php2.jpg', 14, '0000-00-00', '2014-05-05 12:32:48'),
(25, 0, 'pic_1399273368_image.php1.jpg', 14, '0000-00-00', '2014-05-05 12:32:48'),
(26, 0, 'pic_1399273368_image.php.jpg', 14, '0000-00-00', '2014-05-05 12:32:48'),
(27, 0, 'pic_1399282142_images.jpg', 14, '0000-00-00', '2014-05-05 14:59:02'),
(28, 0, 'pic_1399282285_images.jpg', 14, '0000-00-00', '2014-05-05 15:01:25'),
(29, 0, 'pic_1399282285_raffalnadal.jpg', 14, '0000-00-00', '2014-05-05 15:01:25'),
(30, 0, 'pic_1399282285_raff.jpg', 14, '0000-00-00', '2014-05-05 15:01:25'),
(31, 0, 'pic_1399282389_img-1.jpg', 14, '0000-00-00', '2014-05-05 15:03:09'),
(32, 0, 'pic_1399282389_img-6.jpg', 14, '0000-00-00', '2014-05-05 15:03:09'),
(33, 0, 'pic_1399282389_img-7.jpg', 14, '0000-00-00', '2014-05-05 15:03:09'),
(34, 0, 'pic_1399282389_img-8.jpg', 14, '0000-00-00', '2014-05-05 15:03:09'),
(35, 0, 'pic_1399359890_index.jpg', 14, '0000-00-00', '2014-05-06 12:34:50'),
(36, 0, 'pic_1399361365_image.php2.jpg', 14, '0000-00-00', '2014-05-06 12:59:25'),
(37, 0, 'pic_1399361365_image.php1.jpg', 14, '0000-00-00', '2014-05-06 12:59:25'),
(38, 0, 'pic_1399361425_image.php2.jpg', 14, '0000-00-00', '2014-05-06 13:00:25'),
(39, 0, 'pic_1399361425_image.php1.jpg', 14, '0000-00-00', '2014-05-06 13:00:25'),
(40, 0, 'pic_1399361425_image.php.jpg', 14, '0000-00-00', '2014-05-06 13:00:25'),
(41, 0, 'pic_1399361450_image.php2.jpg', 14, '0000-00-00', '2014-05-06 13:00:50'),
(42, 0, 'pic_1399361450_image.php1.jpg', 14, '0000-00-00', '2014-05-06 13:00:50'),
(43, 0, 'pic_1399361450_image.php.jpg', 14, '0000-00-00', '2014-05-06 13:00:50'),
(44, 0, 'pic_1399361534_images.jpg', 14, '0000-00-00', '2014-05-06 13:02:14'),
(45, 0, 'pic_1399361534_20140314181933-c9d50591-me.jpg', 14, '0000-00-00', '2014-05-06 13:02:14'),
(46, 0, 'pic_1399361534_raffalnadal.jpg', 14, '0000-00-00', '2014-05-06 13:02:14'),
(47, 0, 'pic_1399361534_raff.jpg', 14, '0000-00-00', '2014-05-06 13:02:14'),
(48, 0, 'pic_1399453213_5-1-2014 1-15-20 PM.png', 14, '0000-00-00', '2014-05-07 14:30:13'),
(49, 0, 'pic_1399454197_5-1-2014 2-51-47 PM.png', 14, '0000-00-00', '2014-05-07 14:46:37'),
(50, 0, 'pic_1399455077_5-1-2014 12-35-12 PM.png', 14, '0000-00-00', '2014-05-07 15:01:17'),
(51, 0, 'pic_1399455077_5-3-2014 1-41-02 PM.png', 14, '0000-00-00', '2014-05-07 15:01:17'),
(52, 0, 'pic_1399455077_5-3-2014 3-33-23 PM.png', 14, '0000-00-00', '2014-05-07 15:01:17'),
(53, 0, 'pic_1399455122_5-1-2014 12-35-12 PM.png', 14, '0000-00-00', '2014-05-07 15:02:02'),
(54, 0, 'pic_1399455131_5-1-2014 1-15-20 PM.png', 14, '0000-00-00', '2014-05-07 15:02:11'),
(55, 0, 'pic_1399455385_images.jpg', 14, '0000-00-00', '2014-05-07 15:06:25'),
(56, 0, 'pic_1399455420_images.jpg', 14, '0000-00-00', '2014-05-07 15:07:00'),
(57, 0, 'pic_1399455460_5-3-2014 1-41-02 PM.png', 14, '0000-00-00', '2014-05-07 15:07:40'),
(58, 0, 'pic_1399455818_image.php2.jpg', 14, '0000-00-00', '2014-05-07 15:13:38'),
(59, 0, 'pic_1399455818_image.php1.jpg', 14, '0000-00-00', '2014-05-07 15:13:38'),
(60, 0, 'pic_1399455891_5-7-2014 11-05-11 AM.png', 14, '0000-00-00', '2014-05-07 15:14:51'),
(61, 0, 'pic_1399455919_5-1-2014 12-35-12 PM.png', 14, '0000-00-00', '2014-05-07 15:15:19'),
(62, 0, 'pic_1399455920_5-1-2014 1-15-20 PM.png', 14, '0000-00-00', '2014-05-07 15:15:20'),
(63, 0, 'pic_1399455920_5-1-2014 2-51-47 PM.png', 14, '0000-00-00', '2014-05-07 15:15:20'),
(64, 0, 'pic_1399456111_5-1-2014 2-51-47 PM.png', 14, '0000-00-00', '2014-05-07 15:18:31'),
(65, 0, 'pic_1399456111_5-1-2014 12-35-12 PM.png', 14, '0000-00-00', '2014-05-07 15:18:31'),
(66, 0, 'pic_1399456111_5-3-2014 1-41-02 PM.png', 14, '0000-00-00', '2014-05-07 15:18:31'),
(67, 0, 'pic_1399456163_5-3-2014 1-41-02 PM.png', 14, '0000-00-00', '2014-05-07 15:19:23'),
(68, 0, 'pic_1399456163_5-1-2014 2-51-47 PM.png', 14, '0000-00-00', '2014-05-07 15:19:23'),
(69, 0, 'pic_1399456163_5-1-2014 12-35-12 PM.png', 14, '0000-00-00', '2014-05-07 15:19:23'),
(70, 0, 'pic_1399456190_5-1-2014 2-51-47 PM.png', 14, '0000-00-00', '2014-05-07 15:19:50'),
(71, 0, 'pic_1399456191_5-1-2014 12-35-12 PM.png', 14, '0000-00-00', '2014-05-07 15:19:51'),
(72, 0, 'pic_1399456191_5-3-2014 1-41-02 PM.png', 14, '0000-00-00', '2014-05-07 15:19:51'),
(73, 0, 'pic_1399456231_5-5-2014 3-30-00 PM.png', 14, '0000-00-00', '2014-05-07 15:20:31'),
(74, 0, 'pic_1399456231_5-6-2014 1-12-39 PM.png', 14, '0000-00-00', '2014-05-07 15:20:31'),
(75, 0, 'pic_1399456231_images.jpg', 14, '0000-00-00', '2014-05-07 15:20:31'),
(76, 0, 'pic_1399456258_5-1-2014 12-35-12 PM.png', 14, '0000-00-00', '2014-05-07 15:20:58'),
(77, 0, 'pic_1399456259_5-3-2014 1-41-02 PM.png', 14, '0000-00-00', '2014-05-07 15:20:59'),
(78, 0, 'pic_1399456259_5-3-2014 3-33-23 PM.png', 14, '0000-00-00', '2014-05-07 15:20:59'),
(79, 0, 'pic_1399456284_5-5-2014 3-30-00 PM.png', 14, '0000-00-00', '2014-05-07 15:21:24'),
(80, 0, 'pic_1399456284_5-6-2014 1-12-39 PM.png', 14, '0000-00-00', '2014-05-07 15:21:24'),
(81, 0, 'pic_1399456284_5-7-2014 11-05-11 AM.png', 14, '0000-00-00', '2014-05-07 15:21:24'),
(82, 0, 'pic_1399457965_5-1-2014 1-15-20 PM.png', 14, '0000-00-00', '2014-05-07 15:49:25'),
(83, 0, 'pic_1399458379_5-1-2014 12-35-12 PM.png', 14, '0000-00-00', '2014-05-07 15:56:19'),
(84, 0, 'pic_1399637602_image.php1.jpg', 14, '0000-00-00', '2014-05-09 17:43:22'),
(85, 0, 'pic_1399637631_image.php2.jpg', 14, '0000-00-00', '2014-05-09 17:43:51'),
(86, 0, 'pic_1399637701_image.php2.jpg', 14, '0000-00-00', '2014-05-09 17:45:01'),
(87, 0, 'pic_1399637701_image.php1.jpg', 14, '0000-00-00', '2014-05-09 17:45:01'),
(88, 0, 'pic_1399637701_image.php.jpg', 14, '0000-00-00', '2014-05-09 17:45:01'),
(89, 0, 'pic_1399637733_image.php1.jpg', 14, '0000-00-00', '2014-05-09 17:45:33'),
(90, 0, 'pic_1399643585_pl sel fltr.PNG', 14, '0000-00-00', '2014-05-09 19:23:05'),
(91, 0, 'pic_1399643730_pl sel fltr.PNG', 14, '0000-00-00', '2014-05-09 19:25:30'),
(92, 0, 'pic_1399643865_pl sel fltr.PNG', 14, '0000-00-00', '2014-05-09 19:27:45'),
(93, 0, 'pic_1399643938_pl sel fltr.PNG', 14, '0000-00-00', '2014-05-09 19:28:58'),
(94, 0, 'pic_1399643994_pl sel fltr.PNG', 14, '0000-00-00', '2014-05-09 19:29:54'),
(95, 0, 'pic_1399644094_pl sel fltr.PNG', 14, '0000-00-00', '2014-05-09 19:31:34'),
(96, 0, 'pic_1399644127_pl sel fltr.PNG', 14, '0000-00-00', '2014-05-09 19:32:07');

-- --------------------------------------------------------

--
-- Table structure for table `tempusers`
--

CREATE TABLE IF NOT EXISTS `tempusers` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `gender` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tempusers`
--


-- --------------------------------------------------------

--
-- Table structure for table `twitter`
--

CREATE TABLE IF NOT EXISTS `twitter` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(70) DEFAULT NULL,
  `oauth_uid` varchar(200) DEFAULT NULL,
  `oauth_provider` varchar(200) DEFAULT NULL,
  `username` varchar(100) DEFAULT NULL,
  `twitter_oauth_token` varchar(200) DEFAULT NULL,
  `twitter_oauth_token_secret` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `twitter`
--

INSERT INTO `twitter` (`id`, `email`, `oauth_uid`, `oauth_provider`, `username`, `twitter_oauth_token`, `twitter_oauth_token_secret`) VALUES
(1, NULL, '2509914050', 'twitter', 'yuvraj', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `updatedmessages`
--

CREATE TABLE IF NOT EXISTS `updatedmessages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `article_idd` int(11) NOT NULL,
  `description` text NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=80 ;

--
-- Dumping data for table `updatedmessages`
--

INSERT INTO `updatedmessages` (`id`, `article_idd`, `description`, `date`) VALUES
(1, 108, '<p>sfdsf</p><p>dsfdsf</p><p>dsfds</p>', '2014-07-22 19:38:12'),
(2, 108, '<p>dasds</p><p>dasd</p><p>das</p><p>ds</p>', '2014-07-22 19:39:28'),
(3, 107, '<p>hello</p><p>how are you?</p><p>thanks</p>', '2014-07-23 09:38:58'),
(5, 110, '<p><p><span class="sf-middle db fl">Tony is waging a war against a very  aggressive brain cancer. This is devastating news and we need to show  them our love and support!</span></p></p>', '2014-07-25 18:34:20'),
(6, 114, '<p><p>sdffdsf</p></p>', '2014-07-31 11:38:25'),
(7, 114, '<p><p>xcxc</p></p>', '2014-07-31 11:39:17'),
(8, 114, '<p><p>sddsfvcbfcg</p></p>', '2014-07-31 11:39:42'),
(9, 114, '<p><p>dgfdg</p></p>', '2014-07-31 11:59:18'),
(10, 114, '<p><p>dfgdfgdf</p></p>', '2014-07-31 11:59:26'),
(11, 114, '<p><p>gfbgf</p></p>', '2014-07-31 12:00:04'),
(12, 114, '<p><p>dfgdg</p></p>', '2014-07-31 12:00:51'),
(13, 114, '<p><p>fdsfds</p></p>', '2014-07-31 12:05:00'),
(14, 114, '<p><p>adsadasdasd</p></p>', '2014-07-31 12:06:06'),
(15, 114, '<p><p>hello</p></p>', '2014-07-31 12:07:42'),
(16, 114, '<p><p>sdfsdf</p></p>', '2014-07-31 12:10:28'),
(17, 114, '<p><p>asdas</p></p>', '2014-07-31 12:15:09'),
(18, 115, '<p><p>hello</p></p>', '2014-07-31 12:28:33'),
(19, 115, '<p><p>asdad</p></p>', '2014-07-31 12:30:29'),
(20, 115, '<p><p>dd</p></p>', '2014-07-31 12:33:30'),
(21, 115, '<p><p>ss</p></p>', '2014-07-31 12:33:39'),
(22, 115, '<p><p>sdsd</p></p>', '2014-07-31 12:34:22'),
(23, 115, '<p><p>sads</p></p>', '2014-07-31 12:35:41'),
(24, 115, '<p><p>fdsfds</p></p>', '2014-07-31 12:36:24'),
(25, 115, '<p><p>dfdsf</p></p>', '2014-07-31 12:36:31'),
(26, 115, '<p><p>dasdas</p></p>', '2014-07-31 12:39:10'),
(27, 115, '<p><p>sad</p></p>', '2014-07-31 12:42:19'),
(28, 115, '<p><p>fsdfds</p></p>', '2014-07-31 14:01:39'),
(29, 115, '<p><p>dasawdwa</p></p>', '2014-07-31 14:05:59'),
(30, 117, '<p><p><img width="640" height="480" src="http://softprodigy.in/GoFundMe/img/editorimages/image/scenery3.jpg" alt="" /></p></p>', '2014-07-31 14:47:51'),
(31, 118, '<p><pre class="prettyprint"><span class="kwd">var</span><span class="pln"> oEditor </span><span class="pun">=</span><span class="pln"> </span><span class="typ">FCKeditorAPI</span><span class="pun">.</span><span class="typ">GetInstance</span><span class="pun">(</span><span class="str">''instance''</span><span class="pun">)</span><span class="pln"> </span><span class="pun">;</span><span class="pln"> </span><span class="kwd">var</span><span class="pln"> pageValue </span><span class="pun">=</span><span class="pln"> oEditor</span><span class="pun">.</span><span class="typ">GetHTML</span><span class="pun">(); <img width="160" height="109" src="http://softprodigy.in/GoFundMe/img/editorimages/image/gatorade-g-series.jpeg" alt="" /><br /></span></pre></p>', '2014-07-31 15:24:33'),
(32, 118, '<p><p>dsfds</p></p>', '2014-07-31 15:24:49'),
(33, 118, '<p><p>dsdsf</p></p>', '2014-07-31 15:25:03'),
(34, 118, '<p><p>dsf</p></p><p><p>&nbsp;</p></p>', '2014-07-31 15:26:25'),
(35, 119, '<p><p>fgffhgfh</p></p>', '2014-07-31 15:41:13'),
(36, 119, '<p><p>fgf</p></p>', '2014-07-31 15:49:35'),
(37, 119, '<p><p>asd</p></p>', '2014-07-31 15:50:32'),
(38, 119, '<p><p>test</p></p>', '2014-07-31 15:51:51'),
(39, 119, '<p><p>dfdsf</p></p>', '2014-07-31 15:54:36'),
(40, 119, '<p><p>fdsfds</p></p>', '2014-07-31 15:55:19'),
(41, 119, '<p><p>fgdfgdf</p></p>', '2014-07-31 15:57:13'),
(42, 119, '<p>dfdssfsf</p>', '2014-07-31 16:00:53'),
(43, 119, '<p><p>dfsfsf</p></p>', '2014-07-31 16:06:46'),
(44, 106, '<p><p>fdg</p></p>', '2014-07-31 16:49:56'),
(45, 106, '<p><p>dsd</p></p>', '2014-07-31 16:50:40'),
(46, 106, '<p><p>hhhhhhh</p></p>', '2014-07-31 16:51:32'),
(47, 108, '<p><p>message</p></p>', '2014-07-31 17:31:25'),
(48, 108, '<p><p>test</p></p>', '2014-07-31 17:33:25'),
(49, 108, '<p><p>dfgdg</p></p>', '2014-07-31 17:47:12'),
(50, 108, '<p><p>ggg</p></p>', '2014-07-31 17:48:03'),
(51, 108, '<p><p>ggg</p></p>', '2014-07-31 17:49:35'),
(52, 108, '<p><p>fdgfdg</p></p>', '2014-07-31 17:49:41'),
(53, 108, '<p><p>hhh</p></p>', '2014-07-31 17:50:31'),
(54, 121, '<p><p>Tony is waging a war against a very aggressive brain cancer. This is   devastating news and we need to show them our love and support!</p></p><p><p>Tony is waging a war against a very aggressive brain cancer. This is   devastating news and we need to show them our love and support!</p></p><p><p><img width="240" height="180" src="http://softprodigy.in/GoFundMe/img/editorimages/image/scenery3.jpg" alt="" /></p></p>', '2014-07-31 18:14:37'),
(55, 114, '<p><p>Tony is waging a war against a very aggressive brain cancer. This is   devastating news and we need to show them our love and support!</p></p><p><p>Tony is waging a war against a very aggressive brain cancer. This is   devastating news and we need to show them our love and support!</p></p><p><p><img width="440" height="330" src="http://softprodigy.in/GoFundMe/img/editorimages/image/scenery3.jpg" alt="" /></p></p><p><p><img width="440" height="330" src="http://softprodigy.in/GoFundMe/img/editorimages/image/scenery3.jpg" alt="" /></p></p><p><p><img width="440" height="293" src="http://softprodigy.in/GoFundMe/img/editorimages/image/lake-scenery-wallpapers_6612_1024.jpg" alt="" /></p></p>', '2014-07-31 18:43:49'),
(56, 114, '<p><p>PageDescription</p></p><p><p>PageDescription</p></p><p><p><img width="440" height="330" src="http://softprodigy.in/GoFundMe/img/editorimages/image/scenery3.jpg" alt="" /></p></p>', '2014-07-31 18:54:02'),
(57, 108, '<p><p>kkk</p></p>', '2014-07-31 22:01:08'),
(58, 112, '<p><p style="text-align: justify;">Just three weeks before Cassie was supposed to start college, her mother   passed away. Due to complications, Cassie no longer qualified for   financial aid and her academic future looked bleak. Thousands were   touched by her story, and donated enough money to help keep Cassie in   school.</p></p><p><p style="text-align: justify;"><img width="600" height="260" src="http://softprodigy.in/GoFundMe/img/editorimages/image/scenery3.jpg" alt="" /></p></p>', '2014-08-21 18:35:22'),
(60, 112, '<p><p>Just three weeks before Cassie was supposed to start college, her mother    passed away. Due to complications, Cassie no longer qualified for    financial aid and her academic future looked bleak. Thousands were    touched by her story, and donated enough money to help keep Cassie in    school.</p></p><p><p><img width="600" height="260" src="http://softprodigy.in/GoFundMe/img/editorimages/image/lake-scenery-wallpapers_6612_1024(1).jpg" alt="" /></p></p>', '2014-08-21 18:45:54'),
(61, 130, '<p><p>Updayes </p></p><p><p>Updayes </p></p><p><p>Updayes </p></p><p><p>Updayes </p></p><p><p>Updayes </p></p><p><p>Updayes </p></p>', '2014-09-11 16:04:07'),
(62, 113, '<p><p>wadwa</p></p>', '2014-09-29 17:53:04'),
(63, 113, '<p><p>dss</p></p>', '2014-09-29 17:58:49'),
(64, 113, '<p><p>dsfdsf</p></p>', '2014-09-29 18:00:07'),
(65, 113, '<p><p>s</p></p>', '2014-09-29 18:03:27'),
(66, 142, '<p><p>This is my First message.</p></p>', '2014-09-29 20:53:05'),
(67, 142, '<p><p>This is my second message.</p></p>', '2014-09-29 20:53:47'),
(68, 130, '<p><p>fdfsd f test</p></p>', '2014-09-30 13:10:13'),
(69, 94, '<p><p>test</p></p>', '2014-09-30 13:10:59'),
(72, 143, '<p><p><img alt="" src="http://media1.santabanta.com/full1/Cricket/Yuvraj%20Singh/yuvraj-singh-29a.jpg" style="height:150px; width:200px"></p></p>', '2014-10-18 14:52:43'),
(74, 143, '<p><p><img alt="" src="http://media1.santabanta.com/full1/Cricket/Yuvraj%20Singh/yuvraj-singh-29a.jpg" style="height:450px; width:600px"></p></p>', '2014-10-18 15:00:33'),
(75, 143, '<p><p><img alt="" src="http://wallmobi.net/res.php?src=/uploads/pictures/sport/35802-yuvraj-singh.jpg&amp;h=218&amp;w=340&amp;zc=1" style="height:218px; width:340px"></p></p>', '2014-10-18 15:02:44'),
(76, 143, '<p><p><img alt="" src="http://wallmobi.net/res.php?src=/uploads/pictures/sport/35802-yuvraj-singh.jpg&amp;h=218&amp;w=340&amp;zc=1" style="height:218px; width:301px"><img alt="" src="http://wallmobi.net/res.php?src=/uploads/pictures/sport/35802-yuvraj-singh.jpg&amp;h=218&amp;w=340&amp;zc=1" style="height:181px; width:282px"></p></p>', '2014-10-18 15:04:06'),
(77, 143, '<p><p><img alt="" src="http://wallmobi.net/res.php?src=/uploads/pictures/sport/35802-yuvraj-singh.jpg&amp;h=218&amp;w=340&amp;zc=1" style="height:218px; width:340px"></p></p>', '2014-10-18 15:07:09'),
(78, 143, '<p><p><img alt="" src="http://wallmobi.net/res.php?src=/uploads/pictures/sport/35802-yuvraj-singh.jpg&amp;h=218&amp;w=340&amp;zc=1" style="height:218px; width:340px"></p></p>', '2014-10-18 15:13:53'),
(79, 143, '<p><p><img alt="" src="http://www.cricketinteract.com/resource/players/11601/images/36084.jpg" style="height:751px; width:600px"></p></p>', '2014-11-03 14:09:40');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `username` varchar(20) NOT NULL,
  `email` varchar(255) NOT NULL,
  `day` int(11) NOT NULL,
  `month` int(11) NOT NULL,
  `year` int(11) NOT NULL,
  `password` varchar(255) NOT NULL,
  `orgpassword` varchar(255) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `address` text NOT NULL,
  `zip` int(255) NOT NULL,
  `contact` bigint(255) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `status` int(10) NOT NULL DEFAULT '0',
  `wepayUserID` varchar(255) NOT NULL,
  `wepayAccesstoken` varchar(255) NOT NULL,
  `wepayAccountID` varchar(255) NOT NULL,
  `wepayState` varchar(255) NOT NULL,
  `email_confirmation` int(50) NOT NULL,
  `fbUniqueID` varchar(255) DEFAULT NULL,
  `twUniqueID` varchar(255) DEFAULT NULL,
  `isFBorTwitter` varchar(255) DEFAULT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3555 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `firstname`, `lastname`, `username`, `email`, `day`, `month`, `year`, `password`, `orgpassword`, `gender`, `address`, `zip`, `contact`, `image`, `status`, `wepayUserID`, `wepayAccesstoken`, `wepayAccountID`, `wepayState`, `email_confirmation`, `fbUniqueID`, `twUniqueID`, `isFBorTwitter`, `date`) VALUES
(1216, 'rajj', 'dhiman', 'raj dhiman', 'raj_dhiman@softprodigy.com', 0, 0, 0, '827ccb0eea8a706c4c34a16891f84e7b', NULL, NULL, 'chd', 12345, 0, 'team-member04.png', 1, '161796572', 'STAGE_bd20db299b940755c3a699883255bd5ef1718c132e7f8760c97b8b6e9106d2bb', '2014054713', 'pending', 1, NULL, NULL, NULL, '0000-00-00 00:00:00'),
(1214, 'anit', 'amit', 'ashwani', 'sharma.akshat3184@yahoo.com', 0, 0, 0, '827ccb0eea8a706c4c34a16891f84e7b', NULL, NULL, 'chd', 12345, 9874563212, '', 1, '132635642', 'STAGE_129b2eca5804719f6e395de51eb4eed57c550e4fda361239b642f21ef0709e1f', '648869358', 'pending', 1, NULL, NULL, NULL, '0000-00-00 00:00:00'),
(1235, 'Jayant', 'Sharma', '1', 'xssdadas@sdf.com', 0, 0, 0, 'e10adc3949ba59abbe56e057f20f883e', '123456', NULL, '', 0, 0, '', 0, '', '', '', '', 0, NULL, NULL, NULL, '2014-06-20 15:58:11'),
(1234, 'Jayant', 'Sharma', 'jayant123sharma', 'jayant123sharma@hotmail.com', 0, 0, 0, 'e10adc3949ba59abbe56e057f20f883e', '123456', NULL, 'Phase- 8 , industrial area, chandigarh', 160055, 0, '294693_274201026023707_1307321335_n.jpg', 1, '', '', '', '', 1, NULL, NULL, NULL, '2014-06-20 15:49:42'),
(1248, 'Gaurav  ss', 'Saini  ss', 'Gaurav123', 'gauravsoftprodigy1@gmail.com', 0, 0, 0, 'e10adc3949ba59abbe56e057f20f883e', '123456', NULL, 'Mohali', 160055, 0, 'imagescv.jpg', 1, '', '', '', '', 1, NULL, NULL, NULL, '2014-06-27 13:32:33'),
(1263, 'Raj dhiman', 'Softprodigy d', 'Raj Softprodigy', 'raj.softprodigy@gmail.com', 0, 0, 0, '000', NULL, 'male', 'Warsaw, Poland', 0, 0, 'baby-boy-wearing-hat.jpg', 1, '', '', '', '', 1, '711257885606963', 'null', 'facebook', '2014-07-03 17:37:56'),
(1367, 'punnet', 'kaushal', 'puneet', 'punitkaushal790@gmail.com', 0, 0, 0, 'e10adc3949ba59abbe56e057f20f883e', '123456', NULL, 'chd', 12345, 0, 'baby-boy-wearing-hat.jpg', 1, '', '', '', '', 1, NULL, NULL, NULL, '2014-07-30 13:32:10'),
(1232, 'nitin', 'joshi', 'nitin_softprodigy', 'nitin.softprodigy@gmail.com', 0, 0, 0, 'e10adc3949ba59abbe56e057f20f883e', '123456', NULL, '', 0, 0, 'Blue hills.jpg', 1, '', '', '', '', 1, NULL, NULL, NULL, '2014-06-19 18:58:10'),
(1239, 'sfsdf', 'dsfdsf', 'dsfdsf', 'dsfdsff@gmail.com', 0, 0, 0, '827ccb0eea8a706c4c34a16891f84e7b', NULL, NULL, '', 0, 9876543212, 'user_1403266875_IMG-5.jpg', 1, '', '', '', '', 1, NULL, NULL, NULL, '2014-06-20 17:51:15'),
(1240, 'sfsdf', 'dsfdsf', 'dsfdsfwadawsd', 'dsfdsfdsasdf@gmail.com', 0, 0, 0, '827ccb0eea8a706c4c34a16891f84e7b', NULL, NULL, '', 0, 9876543212, 'user_1403266962_IMG-2.jpg', 1, '', '', '', '', 1, NULL, NULL, NULL, '2014-06-20 17:52:43'),
(1241, 'sfsdf', 'dsfdsf', 'dsfdsfwadawasdasdsd', 'dsfdsfdsasdasdasdf@gmail.com', 0, 0, 0, '827ccb0eea8a706c4c34a16891f84e7b', NULL, NULL, '', 0, 9876543212, 'user_1403266995_IMG-2.jpg', 1, '', '', '', '', 1, NULL, NULL, NULL, '2014-06-20 17:53:15'),
(1242, 'raghav', 'jhkjlh', 'jhkjh@gmail.com', 'jhkl@gmail.com', 0, 0, 0, '827ccb0eea8a706c4c34a16891f84e7b', NULL, NULL, '', 0, 9876543212, '', 1, '', '', '', '', 1, NULL, NULL, NULL, '2014-06-20 18:02:32'),
(1243, 'raghav', 'sharma', 'jhkddsf', 'jhkddsfdsffdsl@gmail.com', 0, 0, 0, '827ccb0eea8a706c4c34a16891f84e7b', NULL, NULL, '', 0, 9874563210, '', 1, '', '', '', '', 1, NULL, NULL, NULL, '2014-06-20 18:05:30'),
(1244, 'raghav1', 'sharma1', 'raghav', 'raghav.vashishth@gmail.com', 0, 0, 0, 'e10adc3949ba59abbe56e057f20f883e', '123456', NULL, '', 0, 0, 'IMG-5.jpg', 1, '', '', '', '', 1, NULL, NULL, NULL, '2014-06-20 18:49:38'),
(1245, 'test', 'test', 'test', 'test@gmail.com', 0, 0, 0, 'e10adc3949ba59abbe56e057f20f883e', '123456', NULL, 'chd', 1001, 0, NULL, 0, '', '', '', '', 0, NULL, NULL, NULL, '2014-06-24 11:15:33'),
(1246, 'Michael', 'Chase', 'capstonedesign', 'info@capstonedesigngroup.com', 0, 0, 0, '3894668346cdba083ac40d4bf75b16a9', '>&D2rf4U8(', NULL, '7800 Falls of Neuse Rd', 27624, 0, NULL, 1, '', '', '', '', 1, NULL, NULL, NULL, '2014-06-24 21:28:05'),
(1249, 'ashwani', 'rana', 'ashwanirrr', 'ashwani.softprodigy@gmail.com', 0, 0, 0, 'e10adc3949ba59abbe56e057f20f883e', '123456', NULL, 'chd mohali house no-10', 12345, 0, NULL, 1, '', '', '', '', 1, NULL, NULL, NULL, '2014-06-30 17:39:07'),
(1251, 'eetret', 'etert', 'hjkhk', 'teettte@gmail.com', 0, 0, 0, 'e10adc3949ba59abbe56e057f20f883e', '123456', NULL, 'ghh', 12345, 0, NULL, 0, '', '', '', '', 0, NULL, NULL, NULL, '2014-06-30 17:57:11'),
(1252, 'neeraj', 'Sarathe', 'neeraj123', 'neerajsoftprodigy1@gmail.com', 0, 0, 0, 'e10adc3949ba59abbe56e057f20f883e', '123456', NULL, 'Bhopal, MP', 175432, 0, NULL, 0, '', '', '', '', 0, NULL, NULL, NULL, '2014-07-01 12:36:58'),
(1265, 'Krish', 'Bhasin', 'Krish Bhasin', 'krish.k.bhasin@gmail.com', 0, 0, 0, '000', NULL, 'male', '', 0, 0, 'fb_730097773695640_pic.jpg', 1, '', '', '', '', 1, '730097773695640', 'null', 'facebook', '2014-07-03 18:16:24'),
(1266, 'yatin', 'sharma', 'yatin', 'abc@gmail.com', 0, 0, 0, 'e10adc3949ba59abbe56e057f20f883e', '123456', NULL, 'chd', 123456, 0, NULL, 1, '', '', '', '', 1, NULL, NULL, NULL, '2014-07-03 20:10:04'),
(1268, 'Puneet', 'Kaushal', 'Puneet Kaushal', 'punitkaushal@yahoo.in', 0, 0, 0, '000', NULL, 'male', 'chandighar', 12345, 0, 'fb_804035339616278_pic.jpg', 1, '', '', '', '', 1, '804035339616278', 'null', 'facebook', '2014-07-10 10:56:06'),
(1269, 'Jayant', 'Sharma', 'Jayant Sharma', 'jayant013mysteryguy@gmail.com', 0, 0, 0, '000', NULL, 'male', 'Paonta Sahib,', 173025, 0, 'fb_906204966061264_pic.jpg', 1, '', '', '', '', 1, '906204966061264', 'null', 'facebook', '2014-07-14 12:01:28'),
(1267, 'sdfsfsdf', 'dsfsdf', 'fdsfsdf', 'fdsfdsfdsf@gmail.com', 0, 0, 0, 'e10adc3949ba59abbe56e057f20f883e', NULL, NULL, '', 0, 9876321456, '', 1, '', '', '', '', 1, NULL, NULL, NULL, '2014-07-09 22:14:29'),
(1985, 'Kanchan', 'Grover', 'Kanchan Grover', 'kanchan.softprodigy@gmail.com', 0, 0, 0, 'c33367701511b4f6020ec61ded352059', '654321', NULL, 'House no. 4220, Sirsa, Haryana', 192837, 0, 'abc.png', 1, '', '', '', '', 1, NULL, NULL, NULL, '2014-08-29 11:21:16'),
(1271, 'ashwani', 'kaushal', 'ashwanik.softprodigy', 'ashwani_kaushal@outlook.com', 0, 0, 0, 'e10adc3949ba59abbe56e057f20f883e', '123456', NULL, 'chd', 202020, 0, NULL, 0, '', '', '', '', 0, NULL, NULL, NULL, '2014-07-23 12:54:12'),
(1949, 'Pankaj', 'Chopra', 'Pankaj Chopra', 'pankaj.softprodigy@gmail.com', 0, 0, 0, '000', NULL, 'male', '', 0, 0, 'fb_672702662823500_pic.jpg', 1, '', '', '', '', 1, '672702662823500', 'null', 'facebook', '2014-08-21 14:32:27'),
(1986, 'deepak', 'sharma', 'deepak sharma', 'deepak@gmail.com', 0, 0, 0, '827ccb0eea8a706c4c34a16891f84e7b', '12345', NULL, 'chd', 124140, 0, 'article-image.png', 1, '', '', '', '', 1, NULL, NULL, NULL, '2014-09-10 10:57:34'),
(3230, 'Pardeep', 'Grover', 'Pardeep Grover', 'pardeep310@gmail.com', 0, 0, 0, '000', NULL, 'male', '', 0, 0, 'fb_710598319017780_pic.jpg', 1, '', '', '', '', 1, '710598319017780', 'null', 'facebook', '2014-10-06 13:59:30'),
(3233, 'ashwani', 'kaushal', 'Ashwani kaushal', 'testfor@gmail.com', 0, 0, 0, 'e10adc3949ba59abbe56e057f20f883e', '123456', NULL, 'chd', 12345, 0, 'mid_section_img_003.jpg', 1, '', '', '', '', 1, NULL, NULL, NULL, '2014-10-17 20:23:59'),
(3553, '', '', 'tettst', 'zxzxzxzxx@gmail.com', 0, 0, 0, 'e10adc3949ba59abbe56e057f20f883e', '123456', NULL, '', 0, 0, NULL, 0, '', '', '', '', 0, NULL, NULL, NULL, '2014-10-18 16:23:56'),
(3554, 'Aakshat', 'Sharma', 'Aakshat Sharma', 'akshat8400@gmail.com', 0, 0, 0, '000', NULL, 'male', '', 0, 0, 'fb_10152512739753063_pic.jpg', 1, '', '', '', '', 1, '10152512739753063', 'null', 'facebook', '2014-10-28 15:50:50');

-- --------------------------------------------------------

--
-- Table structure for table `wishlists`
--

CREATE TABLE IF NOT EXISTS `wishlists` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `article_id` int(11) NOT NULL,
  `created` datetime DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=73 ;

--
-- Dumping data for table `wishlists`
--

INSERT INTO `wishlists` (`id`, `user_id`, `author_id`, `article_id`, `created`, `updated`) VALUES
(50, 1216, 1246, 111, '2014-07-24 15:56:18', '2014-07-24 15:56:18'),
(51, 1216, 1216, 112, '2014-07-24 16:02:55', '2014-07-24 16:02:55'),
(52, 1233, 1233, 106, '2014-07-25 14:23:51', '2014-07-25 14:23:51'),
(53, 1233, 1234, 110, '2014-07-25 16:01:45', '2014-07-25 16:01:45'),
(54, 1234, 1234, 110, '2014-07-25 18:18:24', '2014-07-25 18:18:24'),
(55, 1234, 1233, 106, '2014-07-25 18:31:59', '2014-07-25 18:31:59'),
(56, 1234, 1216, 112, '2014-07-25 18:32:08', '2014-07-25 18:32:08'),
(57, 1367, 1216, 112, '2014-07-30 13:38:21', '2014-07-30 13:38:21'),
(58, 1234, 1234, 94, '2014-07-31 21:09:04', '2014-07-31 21:09:04'),
(61, 1234, 1234, 127, '2014-08-28 16:57:57', '2014-08-28 16:57:57'),
(63, 1233, 1233, 129, '2014-09-02 18:44:09', '2014-09-02 18:44:09'),
(67, 1233, 1234, 127, '2014-09-04 11:12:28', '2014-09-04 11:12:28'),
(70, 1233, 1986, 139, '2014-09-19 13:31:23', '2014-09-19 13:31:23'),
(71, 1248, 1234, 140, '2014-09-22 14:50:56', '2014-09-22 14:50:56'),
(72, 3233, 1248, 141, '2014-10-18 12:06:59', '2014-10-18 12:06:59');
